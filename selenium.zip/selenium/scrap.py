import logging
import json
import time
import os
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

# Set up logging
logging.basicConfig(filename='log.txt', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the URLs from the input.txt file
def read_urls(file_path):
    urls = {}
    with open(file_path, 'r') as file:
        for line in file:
            parts = line.strip().split('\t', 1)  # Split by tab
            if len(parts) == 2:
                urls[parts[0]] = parts[1]
    return urls

# Initialize the web driver
chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = Options()
options.binary_location = os.path.join(chrome_path, "chrome.exe")
driver = webdriver.Chrome(service=service, options=options)
driver.maximize_window()

# Extract categories from the URL
def scrape_categories(url):
    try:
        driver.get(url)
        time.sleep(5)  # Wait for the page to load (adjust as necessary)

        # Example: Assuming categories are in <h1> tags; adjust the selector as needed
        categories = driver.find_elements(By.CSS_SELECTOR, 'h1')
        category_list = [category.text for category in categories]
        return category_list
    except Exception as e:
        logging.error(f"Error scraping {url}: {e}")
        return []

# Write the categories to output.txt
def write_categories_to_file(categories, output_file):
    with open(output_file, 'w') as file:
        for category in categories:
            file.write(f"{category}\n")

# Write the identification data to identification.txt
def write_identification(identification, output_file):
    with open(output_file, 'w') as file:
        for id, timestamp in identification.items():
            file.write(f"{id}\t{timestamp}\n")

# Main execution
def main():
    urls = read_urls('input.txt')
    all_categories = []
    identification = {}

    for id, url in urls.items():
        logging.info(f"Processing {id}: {url}")
        categories = scrape_categories(url)
        if categories:
            all_categories.extend(categories)
        # Record the current timestamp
        timestamp = datetime.now().isoformat()
        identification[id] = timestamp

    write_categories_to_file(all_categories, 'output.txt')
    write_identification(identification, 'identification.txt')

    driver.quit()

if __name__ == "__main__":
    main()
