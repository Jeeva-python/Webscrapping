import os
import time
import json
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = webdriver.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")
web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

def get_data(url):
    web_driver.get(url)
    time.sleep(3)
    script_elements = web_driver.find_elements(By.CSS_SELECTOR, 'script[type="application/ld+json"]')

    for script_element in script_elements:
        try:
            res = json.loads(script_element.get_attribute('innerHTML'))
            if isinstance(res, dict) and res.get('@type') == 'Product':
                return {
                    "brand": res.get('brand', {}).get('name', ''),
                    "sku": res.get('sku', ''),
                    "price": res.get('offers', {}).get('price', ''),
                    "product_id": res.get('productID', ''),
                    "description": res.get('description', ''),
                    "mpn": res.get('sku', '')
                }
        except json.JSONDecodeError:
            continue
    return {
        "brand": '',
        "sku": '',
        "price": '',
        "product_id": '',
        "description": '',
        "mpn": ''
    }

with open("input.txt", "r") as input_file:
    lines = input_file.readlines()

with open("output.txt", "w") as output_file:
    output_file.write("Strike id\tSku\tModel Number\tTitle\tUpc\tbrand\tMpn\tPrice\tProduct weight\n")

    for line in lines[0:]:
        parts = line.strip().split('\t')
        
        Strike_id = parts[0] if len(parts) > 0 else ''
        Sku = parts[1] if len(parts) > 1 else ''
        Model_Number = parts[2] if len(parts) > 2 else ''
        Title = parts[3] if len(parts) > 3 else ''
        Product_url = parts[4] if len(parts) > 4 else ''
        Image_url = parts[5] if len(parts) > 5 else ''
        Upc = ''  
        brand = parts[7] if len(parts) > 7 else ''
        Mpn = parts[8] if len(parts) > 8 else ''
        Price = parts[9] if len(parts) > 9 else ''
        Product_weight = parts[10] if len(parts) > 10 else ''

        product_data = get_data(Product_url)
        
        output_file.write(f"{Strike_id}\t{product_data['sku']}\t{Model_Number}\t{Title}\t{Upc}\t{product_data['brand']}\t{Mpn}\t{product_data['price']}\t{Product_weight}\n")

web_driver.quit()

print("Output Generated")
