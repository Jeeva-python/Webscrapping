from selenium import webdriver
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
import os
from selenium.webdriver.chrome.service import Service

# for holding the resultant list
element_list = []

# Set up Chrome options
# options = webdriver.ChromeOptions()
# You can add additional options here if needed, e.g., options.add_argument("--headless")

# Initialize the WebDriver once
# driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
# options.maximize_window()

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = webdriver.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")
web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

try:
    for page in range(1, 21):  # Adjust the range as needed
        page_url = f"https://webscraper.io/test-sites/e-commerce/static/computers/laptops?page={page}"
        web_driver.get(page_url)
        
        # Use try-except blocks to handle potential issues with element finding
        try:
            titles = web_driver.find_elements(By.CLASS_NAME, "title")
            prices = web_driver.find_elements(By.CLASS_NAME, "price")
            descriptions = web_driver.find_elements(By.CLASS_NAME, "description")
            ratings = web_driver.find_elements(By.CLASS_NAME, "ratings")
            
            # Ensure the lists have the same length
            if len(titles) == len(prices) == len(descriptions) == len(ratings):
                for i in range(len(titles)):
                    element_list.append([
                        titles[i].text, 
                        prices[i].text, 
                        descriptions[i].text, 
                        ratings[i].text
                    ])
            else:
                print("Mismatch in number of elements found.")
                
        except Exception as e:
            print(f"An error occurred while processing the page: {e}")

finally:
    # Close the driver
    web_driver.quit()

print(element_list)
