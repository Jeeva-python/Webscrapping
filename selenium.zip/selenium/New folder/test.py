from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import logging
from datetime import datetime
import time

# Configure logging
logging.basicConfig(
    filename='app.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Read URL from input.txt
input_file = 'input.txt'
try:
    with open(input_file, 'r', encoding='utf-8') as file:
        for item in file:
            col = item.split()
            if len(col) == 2:
                strike_id = col[0]
                url = col[1]
                break
    logging.info(f"URL read from input file: {url}")
except Exception as e:
    logging.error(f"Error reading URL from input file: {e}")
    raise

# Create identification file
identification_file = 'identification.txt'
try:
    with open(identification_file, 'w', encoding='utf-8') as id_file:
        id_file.write(f"Run Date: {datetime.now().strftime('%d_%m_%Y %H:%M:%S')}\n")
        id_file.write(f"Target URL Pattern: {url}\n")
        id_file.write(f"Pages to Scrape: 3\n")
    logging.info(f"Identification file created: {identification_file}")
except Exception as e:
    logging.error(f"Error creating identification file: {e}")
    raise

element_list = []

# Set up WebDriver
try:
    service = Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    web_driver = webdriver.Chrome(service=service, options=options)
    web_driver.maximize_window()
    wait = WebDriverWait(web_driver, 10)
except Exception as e:
    logging.error(f"Error setting up WebDriver: {e}")
    raise

try:
    for page in range(1, 4):
        page_url = f"{url}?page={page}"
        web_driver.get(page_url)
        logging.info(f"Processing page {page} - URL: {page_url}")

        try:
            # Wait for items to be present
            items = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".flex.flex-column.items-center.justify-between.w-100.b--theme-grey-light.bl-l.br-l.bb-l.ph3.pv2")))
            logging.info(f"Found {len(items)} items on page {page}.")
        except Exception as e:
            logging.error(f"An error occurred while waiting for items: {e}")
            continue

        for item in items:
            
                # Scroll into view and click the item
                web_driver.execute_script("arguments[0].scrollIntoView(true);", item)
                ActionChains(web_driver).move_to_element(item).click().perform()
                logging.info(f"Clicked on item.")

                # Wait for the details to load
                time.sleep(3)  # Replace with a more reliable wait if necessary

                # Collect details from the new page
                try:
                    title = wait.until(EC.presence_of_element_located((By.CLASS_NAME, "hover-theme-primary.lh-title.normal.f5.fw3.fw2-ns"))).text
                    model_element = web_driver.find_element(By.CLASS_NAME, "f6.mt1.lh-title.theme-grey.truncate").text
                    rating = web_driver.find_element(By.CLASS_NAME, "f-inherit.fw-inherit.link.theme-primary.f6.pl2.db.underline-hover").text

                    # Extract model number
                    model = ""
                    if "Model:" in model_element:
                        model = model_element.split("Model:")[1].strip()

                    element_list.append([strike_id, title, model, rating])
                    logging.info(f"Collected details - Title: {title}, Model: {model}, Rating: {rating}")
                except Exception as e:
                    logging.error(f"Error while collecting details: {e}")

                # Go back to the previous page
                web_driver.back()
                time.sleep(3)

finally:
    web_driver.quit()
    logging.info("WebDriver has been closed.")

# Write results to output file
try:
    with open('output.txt', 'w', encoding='utf-8') as file:
        file.write("Strike_id\tTitle\tModel_number\tRating\n")
        for item in element_list:
            file.write(f"{item[0]}\t{item[1]}\t{item[2]}\t{item[3]}\n")
    logging.info(f"Results written to output.txt. Total elements collected: {len(element_list)}")
except Exception as e:
    logging.error(f"Error writing results to output file: {e}")
