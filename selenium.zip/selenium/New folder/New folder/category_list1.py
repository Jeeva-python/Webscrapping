import os
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = webdriver.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")
driver = webdriver.Chrome(service=service, options=options)
driver.maximize_window()

hrefs_by_category = {}

with open("input.txt") as file:
    for line in file:
        line = line.strip()
        if not line:
            continue
        
        category, url = line.split("\t")
        driver.get(url)
        
        try:
            selector = "f-inherit fw-inherit link theme-primary  db center mw5"
            elements = WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, selector)))
            hrefs = [elem.get_attribute("href") for elem in elements if elem.get_attribute("href")]
            
            hrefs_by_category[category] = hrefs

        except Exception as e:
            print(f"An error occurred while processing {url}: {e}")

with open("output.txt", "w") as file:
    for category, hrefs in hrefs_by_category.items():
        file.write(f"{category}:\n")
        file.write("\n".join(hrefs) + "\n\n")

print("Href(s) written to output.txt")

driver.quit()
