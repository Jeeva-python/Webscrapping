import os
import time
import json
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Setup logging
logging.basicConfig(filename='app_log.txt', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

IDENTIFICATION_FILE = "identification.txt"
INPUT_FILE = "input.txt"
OUTPUT_FILE = "output.txt"

def initialize_web_driver():
    try:
        chrome_path = os.getenv('chrome')
        if not chrome_path:
            raise EnvironmentError("The 'chrome' environment variable is not set.")
        
        service = Service(os.path.join(chrome_path, "chromedriver.exe"))
        options = webdriver.ChromeOptions()
        options.binary_location = os.path.join(chrome_path, "chrome.exe")
        
        driver = webdriver.Chrome(service=service, options=options)
        driver.maximize_window()
        return driver
    except Exception as e:
        logging.error(f"Error initializing web driver: {e}")
        raise

def get_data(url, driver):
    """Fetch data from the given URL using the WebDriver."""
    logging.info(f"Fetching data from URL: {url}")
    try:
        driver.get(url)
        WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.TAG_NAME, 'script')))
        retries = 3
        for _ in range(retries):
            try:
                script_tags = driver.find_elements(By.TAG_NAME, 'script')
                json_type = [script for script in script_tags if script.get_attribute('type') == 'application/ld+json']
                for item in json_type:
                    try:
                        json_content = item.get_attribute('innerHTML')
                        res = json.loads(json_content)
                        
                        if res.get('@type') == 'Product':
                            return {
                                "brand": res.get('brand', {}).get('name'),
                                "title": res.get('description'),
                                "sku": res.get('sku'),
                                "price": res.get('offers', {}).get('price')
                            }
                    except json.JSONDecodeError:
                        logging.error(f"JSON decoding error for script tag with content: {json_content}")
                logging.warning(f"No valid JSON found in script tags for URL: {url}. Retrying...")
                time.sleep(2)
            except Exception as e:
                logging.error(f"Error retrieving data: {e}")
                time.sleep(2)
        logging.error(f"Failed to retrieve data from URL: {url} after {retries} retries.")
    except Exception as e:
        logging.error(f"Error accessing URL: {url}. Error: {e}")
    
    return {"brand": None, "title": None, "sku": None, "price": None}

def update_identification_file(strike_id: str):
    """Update the identification file with the strike ID and timestamp."""
    try:
        with open(IDENTIFICATION_FILE, "a") as f:
            f.write(f"{strike_id}\t{datetime.now()}\n")
    except IOError as e:
        logging.error(f"Error updating identification file: {e}")

def get_identification_value():
    """Retrieve the last identification value from the identification file."""
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    indent_ids = []
    if os.path.exists(IDENTIFICATION_FILE):
        try:
            with open(IDENTIFICATION_FILE, 'r') as f:
                idents = f.readlines()
            if idents:
                indent_ids = [ident.split('\t')[0] for ident in idents]
        except IOError as e:
            logging.error(f"Error reading identification file: {e}")
    return indent_ids[-1] if indent_ids else 'none'

def process_input_file(driver, retry_missing=False):
    """Process the input file and update the output file with the fetched data."""
    processed_ids = set()
    failed_ids = set()
    results = []
    max_retries = 5

    try:
        with open(INPUT_FILE, 'r') as file:
            input_lines = file.readlines()

        existing_ids = set()
        if os.path.exists(OUTPUT_FILE):
            try:
                with open(OUTPUT_FILE, 'r') as file:
                    lines = file.readlines()[1:]  # Skip header
                    existing_ids = {line.split('\t')[0] for line in lines}
            except IOError as e:
                logging.error(f"Error reading output file: {e}")

        missing_ids = {line.strip().split('\t')[0] for line in input_lines} - existing_ids if retry_missing else {line.strip().split('\t')[0] for line in input_lines} - processed_ids

        for line in input_lines:
            strike_id, url = line.strip().split('\t')

            if strike_id in processed_ids or (retry_missing and strike_id not in missing_ids):
                logging.info(f"Skipping already processed or non-missing ID: {strike_id}")
                continue

            retry_count = 0
            success = False
            while retry_count < max_retries:
                try:
                    data = get_data(url, driver)
                    if all(v is None for v in data.values()):
                        logging.warning(f"No data found for ID: {strike_id}. Retrying...")
                        retry_count += 1
                        time.sleep(5)
                        continue

                    results.append({
                        "strike_id": strike_id,
                        "brand": data['brand'],
                        "title": data['title'],
                        "sku": data['sku'],
                        "price": data['price']
                    })
                    logging.info(f"Successfully processed URL: {url}")
                    update_identification_file(strike_id)
                    success = True
                    break

                except Exception as e:
                    logging.error(f"Error processing ID: {strike_id}. Error: {e}")
                    retry_count += 1
                    time.sleep(5)

            if not success:
                failed_ids.add(strike_id)
                logging.error(f"ID {strike_id} failed after {max_retries} retries")

        if results:
            try:
                with open(OUTPUT_FILE, 'a') as outfile:
                    if os.stat(OUTPUT_FILE).st_size == 0:
                        outfile.write("strike_id\tbrand\ttitle\tsku\tprice\n")
                    for result in results:
                        outfile.write(f"{result['strike_id']}\t{result['brand']}\t{result['title']}\t{result['sku']}\t{result['price']}\n")
                        outfile.flush()
            except IOError as e:
                logging.error(f"Error writing to output file: {e}")

        if failed_ids:
            logging.info(f"Failed IDs: {', '.join(failed_ids)}")

    except Exception as e:
        logging.error(f"Error processing input file: {e}")

if __name__ == "__main__":
    driver = None
    try:
        driver = initialize_web_driver()
        process_input_file(driver)
        process_input_file(driver, retry_missing=True)
    finally:
        if driver:
            driver.quit()
