import os
import time
import json
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Setup logging
logging.basicConfig(filename='app_log.txt', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

IDENTIFICATION_FILE = "identification.txt"
INPUT_FILE = "input.txt"
OUTPUT_FILE = "output.txt"

def initialize_web_driver():
    try:
        chrome_path = os.getenv('chrome')
        if not chrome_path:
            raise EnvironmentError("The 'chrome' environment variable is not set.")
        
        service = Service(os.path.join(chrome_path, "chromedriver.exe"))
        options = webdriver.ChromeOptions()
        options.binary_location = os.path.join(chrome_path, "chrome.exe")
        
        driver = webdriver.Chrome(service=service, options=options)
        driver.maximize_window()
        return driver
    except Exception as e:
        logging.error(f"Error initializing web driver: {e}")
        raise

def get_data(url, driver):
    try:
        driver.get(url)
        
        # Wait for script tags to be loaded
        WebDriverWait(driver, 10).until(
            EC.presence_of_all_elements_located((By.TAG_NAME, 'script'))
        )
        
        # Retry logic for stale element reference
        retries = 3
        for _ in range(retries):
            try:
                script_tags = driver.find_elements(By.TAG_NAME, 'script')
                json_type = [script for script in script_tags if script.get_attribute('type') == 'application/ld+json']
                
                for item in json_type:
                    try:
                        res = json.loads(item.get_attribute('innerHTML'))
                        if isinstance(res, dict) and res.get('@type') == 'Product':
                            return {
                                "brand": res.get('brand', {}).get('name'),
                                "title": res.get('description'),
                                "sku": res.get('sku'),
                                "price": res.get('offers', {}).get('price')
                            }
                    except json.JSONDecodeError:
                        logging.error(f"JSON decoding error for script tag with content: {item.get_attribute('innerHTML')}")
                break  # Break the retry loop if successful
            except Exception as e:
                if 'stale element reference' in str(e).lower():
                    logging.warning(f"Stale element reference encountered: {e}. Retrying...")
                    time.sleep(2)  # Increase delay before retrying
                else:
                    logging.error(f"Error retrieving data from {url}: {e}")
                    break
    except Exception as e:
        logging.error(f"Error retrieving data from {url}: {e}")
    
    # Log what was found if no product data was found
    logging.info(f"No product data found for {url}")
    return {"brand": None, "title": None, "sku": None, "price": None}

def process_input_file(driver):
    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as file:
            processed_ids = set(line.strip().split('\t')[0] for line in file.readlines())
        logging.info(f"Processed IDs: {processed_ids}")

    results = []
    max_retries = 5  # Maximum number of retries for each identifier

    try:
        with open(INPUT_FILE, 'r') as file:
            lines = file.readlines()

        for line in lines:
            identifier, url = line.strip().split('\t')
            logging.info(f"Processing ID: {identifier} with URL: {url}")

            if identifier in processed_ids:
                logging.info(f"Skipping already processed ID: {identifier}")
                continue  # Skip already processed IDs

            retries = 0
            while retries < max_retries:
                try:
                    data = get_data(url, driver)
                    if all(v is None for v in data.values()):
                        logging.warning(f"No data found for ID: {identifier}")
                        retries += 1
                        time.sleep(5)  # Wait before retrying
                        continue

                    results.append({
                        "identifier": identifier,
                        "brand": data['brand'],
                        "title": data['title'],
                        "sku": data['sku'],
                        "price": data['price']
                    })
                    logging.info(f"Processed URL: {url}")
                    update_identification_file(identifier)  # Update identification file with the processed ID
                    break  # Exit retry loop on success

                except Exception as e:
                    logging.error(f"Error processing ID: {identifier}. Attempt {retries + 1}/{max_retries}. Error: {e}")
                    retries += 1
                    time.sleep(5)  # Wait before retrying

        # Write results to output.txt with headers
        with open(OUTPUT_FILE, 'a') as outfile:
            # Write headers only if the file is empty
            if os.stat(OUTPUT_FILE).st_size == 0:
                outfile.write("identifier\tbrand\ttitle\tsku\tprice\n")
            
            # Write data
            for result in results:
                outfile.write(f"{result['identifier']}\t{result['brand']}\t{result['title']}\t{result['sku']}\t{result['price']}\n")
                outfile.flush()  # Flush data to ensure it is written to disk immediately

    except Exception as e:
        logging.error(f"Error processing input file: {e}")

def update_identification_file(prod_id: str):
    try:
        with open(IDENTIFICATION_FILE, "a") as identification_file:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            identification_file.write(f"{prod_id}\t{timestamp}\n")
        logging.info(f"Updated identification file with product ID: {prod_id}")
    except Exception as e:
        logging.error(f"Error updating identification file: {e}")

if __name__ == "__main__":
    driver = None
    try:
        driver = initialize_web_driver()
        process_input_file(driver)
    finally:
        if driver:
            driver.quit()
