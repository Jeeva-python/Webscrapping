from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import os
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(
    filename='app.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'          
)

# Create identification file
identification_file = 'identification.txt'
with open(identification_file, 'w', encoding='utf-8') as id_file:
    id_file.write(f"Run Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    id_file.write(f"Target URL Pattern: URL from input.txt\n")
    id_file.write(f"Pages to Scrape: All available pages\n")

logging.info(f"Identification file created: {identification_file}")

element_list = []

# Read URLs from input.txt
urls = []
with open('input.txt', 'r', encoding='utf-8') as file:
    for line in file:
        parts = line.strip().split('\t')
        if len(parts) == 2:
            urls.append(parts[1])

# Setup WebDriver
chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = webdriver.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")
web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

try:
    for url in urls:
        page_number = 1
        while True:
            page_url = f"{url}?page={page_number}" if page_number > 1 else url
            web_driver.get(page_url)
            logging.info(f"Processing page {page_number} - URL: {page_url}")

            elements = web_driver.find_elements(By.CLASS_NAME, "f-inherit.fw-inherit.link.theme-primary.db.center.mw5")
            if not elements:
                break  # Exit loop if no elements found

            for element in elements:
                href = element.get_attribute('href')
                if href:
                    element_list.append(href)

            logging.info(f"Collected {len(elements)} URLs from page {page_number}.")
            page_number += 1

except Exception as e:
    logging.error(f"An error occurred: {e}")

finally:
    web_driver.quit()
    logging.info("WebDriver has been closed.")

# Write results to output.txt
with open('output.txt', 'w', encoding='utf-8') as file:
    for item in element_list:
        file.write(f"{item}\n")

logging.info(f"Results written to output.txt. Total URLs collected: {len(element_list)}")
