from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import os
import logging
from datetime import datetime
import time

logging.basicConfig(
    filename='app.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

input_file = 'input.txt'
urls = []
with open(input_file, 'r', encoding='utf-8') as file:
    for line in file:
        parts = line.strip().split('\t')
        if len(parts) == 2:
            urls.append(parts[1])

identification_file = 'identification.txt'
with open(identification_file, 'w', encoding='utf-8') as id_file:
    id_file.write(f"Run Date: {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}\n")
    id_file.write(f"Pages to Scrape: {len(urls)}\n")

logging.info(f"Identification file created: {identification_file}")

element_list = []

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = webdriver.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")
web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

def process_page(url):
    web_driver.get(url)
    logging.info(f"Processing URL: {url}")

    while True:
        titles = web_driver.find_elements(By.CLASS_NAME, "hover-theme-primary lh-title normal f5 fw3 fw2-ns tc3-title tc4-title-ns")
        models = web_driver.find_elements(By.CLASS_NAME, "f6 mt1 lh-title theme-grey truncate ")
        ratings = web_driver.find_elements(By.CLASS_NAME, "f-inherit fw-inherit link theme-primary  f6 pl2 db underline-hover")

        num_elements = min(len(titles), len(models), len(ratings))
        print(num_elements)

        if num_elements > 0:
            for i in range(num_elements):
                title_text = titles[i].text if i < len(titles) else "N/A"
                model_text = models[i].text if i < len(models) else "N/A"
                rating_text = ratings[i].text if i < len(ratings) else "N/A"

                element_list.append([
                    title_text,
                    model_text,
                    rating_text,
                ])
            logging.info(f"Collected {num_elements} elements from page.")
        else:
            logging.warning("No elements found on page.")

        try:
            next_button = web_driver.find_element(By.CSS_SELECTOR, 'pointer flex items-center ba br2 theme-grey-darker input-small f6 ph2 hover-theme-primary hover-b--theme-primary')  # Update this XPATH based on your page structure
            if next_button.is_displayed():
                next_button.click()
                time.sleep(2) 
            else:
                break
        except Exception as e:
            logging.warning(f"Next button not found or clickable: {e}")
            break

for url in urls:
    try:
        process_page(url)
    except Exception as e:
        logging.error(f"An error occurred while processing URL: {url} - {e}")

    finally:
        web_driver.quit()
        logging.info("WebDriver has been closed.")

with open('output.txt', 'w', encoding='utf-8') as file:
    file.write("Title\tModel_number\tRating\n")
    
    for item in element_list:
        file.write(f"{item[0]}\t{item[1]}\t{item[2]}\n")

logging.info(f"Results written to output.txt. Total elements collected: {len(element_list)}")
