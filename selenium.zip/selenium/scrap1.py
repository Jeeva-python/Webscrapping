import logging
import os
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up logging
logging.basicConfig(filename='log.txt', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the URLs from the input.txt file
def read_urls(file_path):
    urls = {}
    with open(file_path, 'r') as file:
        for line in file:
            parts = line.strip().split('\t', 1)  # Split by tab
            if len(parts) == 2:
                urls[parts[0]] = parts[1]
    return urls

# Initialize the web driver
def initialize_driver():
    chrome_path = os.getenv('chrome')
    service = Service(os.path.join(chrome_path, "chromedriver.exe"))
    options = Options()
    options.binary_location = os.path.join(chrome_path, "chrome.exe")
    driver = webdriver.Chrome(service=service, options=options)
    driver.maximize_window()
    return driver

# Extract categories and click on each item
def scrape_categories(driver, url):
    categories = []
    try:
        driver.get(url)
        
        # Wait for the main content to load
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '#main-content'))
        )
        
        while True:
            try:
                # Find all category items
                elements = driver.find_elements(By.CSS_SELECTOR, '#main-content > div > div:nth-child(3) > div.dn.db-l.w-25.mr3 > ul > li')
                if not elements:
                    logging.warning(f"No categories found for {url}")
                    break
                
                for i, element in enumerate(elements):
                    try:
                        # Click on the category item
                        element.click()
                        
                        # Wait for potential page load or content change
                        WebDriverWait(driver, 5).until(
                            EC.staleness_of(element)
                        )
                        
                        # Extract the category text
                        category_text = element.text
                        categories.append(category_text)
                        
                        # Return to the previous state
                        driver.back()
                        
                        # Wait for the page to go back
                        WebDriverWait(driver, 5).until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, '#main-content'))
                        )

                    except Exception as e:
                        logging.error(f"Error clicking element {i}: {e}")
                    
                # Check if there is a 'next' page or button to continue
                try:
                    next_button = driver.find_element(By.CSS_SELECTOR, 'a.next')  # Adjust this selector based on your pagination
                    next_button.click()
                    WebDriverWait(driver, 10).until(
                        EC.staleness_of(elements[0])  # Wait until the old elements are no longer present
                    )
                except Exception:
                    # No more pages or an error occurred
                    break

            except Exception as e:
                logging.error(f"Error scraping {url}: {e}")
                break

    except Exception as e:
        logging.error(f"Error accessing {url}: {e}")

    return categories

# Write the categories to output.txt
def write_categories_to_file(categories, output_file):
    with open(output_file, 'w') as file:
        for category in categories:
            file.write(f"{category}\n")

# Write the identification data to identification.txt
def write_identification(identification, output_file):
    with open(output_file, 'w') as file:
        for id, timestamp in identification.items():
            file.write(f"{id}\t{timestamp}\n")

# Main execution
def main():
    driver = initialize_driver()
    urls = read_urls('input.txt')
    all_categories = []
    identification = {}

    for id, url in urls.items():
        logging.info(f"Processing {id}: {url}")
        categories = scrape_categories(driver, url)
        if categories:
            all_categories.extend(categories)
        timestamp = datetime.now().isoformat()
        identification[id] = timestamp

    write_categories_to_file(all_categories, 'output.txt')
    write_identification(identification, 'identification.txt')

    driver.quit()

if __name__ == "__main__":
    main()
