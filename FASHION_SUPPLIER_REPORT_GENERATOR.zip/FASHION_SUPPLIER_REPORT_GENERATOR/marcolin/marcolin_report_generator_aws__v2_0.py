from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

outputs = []

# Read the data from the text file
with open('output.txt', 'r') as f:
    outputs = f.readlines()

# Skip the first line (header) from the file
outputs = outputs[1:]

output_rows = []
header_found = False  # Flag to detect and skip duplicate headers

# Define the correct header to match against
headers = ['Strike_id', 'SKU', 'Brand', 'Model', 'Name', 'Color_code', 'Barcode', 'Manufacturer', 'Size', 'Present', 'Status', 'Stock_Color', 'Wholesale Price (GBP)', 'Retail price (GBP)']
columns_to_keep = [header for header in headers if header != 'Strike_id']

# Process each line, skipping duplicate headers
for output_line in outputs:
    # Skip if the line matches the headers and it's not the first occurrence
    if output_line.strip().upper() == '\t'.join(headers).upper():
        if header_found:  # Skip the second occurrence of headers
            continue
        header_found = True
    
    # Add the row data if it's not a duplicate header
    output_rows.append(output_line.strip().split('\t'))

# Prepare the data by keeping the necessary columns
processed_data = []
for row in output_rows:
    filtered_row = [row[headers.index(col)] for col in columns_to_keep]
    processed_data.append(filtered_row)

# Create a new workbook and a worksheet
wb = Workbook()
ws = wb.active
ws.title = "Summary"

# Define formats
header_input_format = Font(name='Cambria', size=11, color="006100", bold=True)
header_output_format = Font(name='Cambria', size=11, color="9c0031", bold=True)
input_format = Font(name='Cambria', size=11, color="006100")
result_format = Font(name='Cambria', size=11, color="9c0031")

green_fill = PatternFill(start_color="c6efce", end_color="c6efce", fill_type="solid")
red_fill = PatternFill(start_color="ffc7ce", end_color="ffc7ce", fill_type="solid")
border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
alignment = Alignment(vertical='top')

# Write headers to the Excel sheet
for col_num, value in enumerate(columns_to_keep, 1):
    if col_num < 9:
        ws.cell(row=1, column=col_num, value=value).font = header_input_format
        ws.cell(row=1, column=col_num).fill = green_fill
    else:
        ws.cell(row=1, column=col_num, value=value).font = header_output_format
        ws.cell(row=1, column=col_num).fill = red_fill
    ws.cell(row=1, column=col_num).border = border
    ws.cell(row=1, column=col_num).alignment = alignment

# Write data to the Excel sheet
for row_num, row in enumerate(processed_data, 2):
    for col_num, val in enumerate(row, 1):
        cell = ws.cell(row=row_num, column=col_num, value=val)
        
        # Apply number formatting for 'Wholesale Price (GBP)' and 'Retail price (GBP)'
        if columns_to_keep[col_num - 1] in ['Wholesale Price (GBP)', 'Retail price (GBP)']:
            try:
                # Convert to float and apply number format
                cell.value = float(val)
                cell.number_format = '0.00'
            except ValueError:
                pass  # Skip non-numeric values
        
        # Apply the appropriate formatting
        if col_num < 9:
            cell.font = input_format
            cell.fill = green_fill
        else:
            cell.font = result_format
            cell.fill = red_fill
        cell.border = border
        cell.alignment = alignment

# Adjust column widths based on the maximum length of the content
for col_num in range(1, len(columns_to_keep) + 1):
    max_length = 0
    column = get_column_letter(col_num)
    
    for row in ws.iter_rows(min_col=col_num, max_col=col_num):
        for cell in row:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
    adjusted_width = max_length + 2  # Add some padding
    ws.column_dimensions[column].width = adjusted_width

# Save the Excel file
date_time_str = datetime.now().strftime("%d.%m.%Y")
file_name = "Marcolin_Scrap_" + date_time_str + ".xlsx"
wb.save(file_name)

print(f"Excel file saved as {file_name}")
