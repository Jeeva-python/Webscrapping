from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment, NamedStyle
from openpyxl.utils import get_column_letter
from datetime import datetime

# Read the output.txt file
outputs = []
with open('output.txt', 'r') as f:
    outputs = f.readlines()

output_rows = []
for output_line in outputs:
    if output_line.strip().upper().startswith('SKU'):
        continue
    output_rows.append(output_line.strip().split('\t'))

# Define headers and columns to keep
headers = ['Strike_id', 'Sku', 'Brand', 'Name', 'Model no', 'clrcode', 'Color', 'Barcode', 'Size', 'Present', 'Availability', 'Wholesale Price', 'Retail Price']
columns_to_keep = headers[1:]  # Exclude 'Strike_id'

# Create a new workbook and add a worksheet
wb = Workbook()
ws = wb.active
ws.title = "Summary"

# Define styles for headers and data
header_input_style = {
    'font': Font(name='Cambria', size=11, bold=True, color='006100'),
    'fill': PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid'),
    'border': Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
}
header_output_style = {
    'font': Font(name='Cambria', size=11, bold=True, color='9C0031'),
    'fill': PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid'),
    'border': Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
}
input_style = {
    'font': Font(name='Cambria', size=11, color='006100'),
    'fill': PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid'),
    'border': Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
}
result_style = {
    'font': Font(name='Cambria', size=11, color='9C0031'),
    'fill': PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid'),
    'border': Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
}

# Create a number format style for 2 decimal places
decimal_style = NamedStyle(name="decimal_style", number_format="0.00")

# Write headers with styles
for col_num, header in enumerate(columns_to_keep, start=1):
    cell = ws.cell(row=1, column=col_num, value=header)
    if col_num <= 8:
        for attr, value in header_input_style.items():
            setattr(cell, attr, value)
    else:
        for attr, value in header_output_style.items():
            setattr(cell, attr, value)

# Find the index of 'Wholesale Price' and 'Retail Price' columns
wholesale_price_index = columns_to_keep.index('Wholesale Price') + 1  # Adjusting for 1-based indexing
retail_price_index = columns_to_keep.index('Retail Price') + 1

# Write data rows with styles
for row_num, row in enumerate(output_rows[1:], start=2):  # Skip first row
    for col_num, value in enumerate(row[1:], start=1):  # Skip 'Strike_id'
        cell = ws.cell(row=row_num, column=col_num)

        # Check if the value is in the price columns
        if col_num == wholesale_price_index or col_num == retail_price_index:
            try:
                cell.value = float(value.replace(',', '').strip())  # Convert to float (remove commas if present)
                cell.style = decimal_style  # Apply 2 decimal places format
            except ValueError:
                cell.value = value  # In case conversion fails, keep the original value
        else:
            cell.value = value
        
        # Apply input/output styling
        if col_num <= 8:
            for attr, value in input_style.items():
                setattr(cell, attr, value)
        else:
            for attr, value in result_style.items():
                setattr(cell, attr, value)

# Auto-adjust column widths
for col_num, column_cells in enumerate(ws.columns, start=1):
    max_length = max(len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells)
    adjusted_width = max_length + 2
    ws.column_dimensions[get_column_letter(col_num)].width = adjusted_width

# Save the Excel file
date_time_str = datetime.now().strftime("%d.%m.%Y")
wb.save(f"Derigo_Scrap_{date_time_str}.xlsx")
