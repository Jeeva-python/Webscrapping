from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

# Read output file
output_rows = []
with open('output.txt', 'r') as f:
    lines = f.readlines()

# Skip header row and process data
for line in lines:
    if line.strip().upper().startswith('TITLE'):
        continue
    output_rows.append(line.strip().split('\t'))

# Create workbook and sheet
wb = Workbook()
ws = wb.active
ws.title = "Summary"

# Define headers
headers = ['Title', 'Supplier Code', 'SKU', 'UPC', 'Size', 'Colour Code', 'Present', 'Availability', 'Wholesale Price (EUR)', 'SRP (EUR)']
ws.append(headers)

# Define styles
header_input_style = Font(name='Cambria', size=11, bold=True, color='006100')
header_output_style = Font(name='Cambria', size=11, bold=True, color='9C0031')

input_style = Font(name='Cambria', size=11, color='006100')
result_style = Font(name='Cambria', size=11, color='9C0031')

bg_green = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
bg_red = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')

border_style = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

# Apply header styles
for col_num, header in enumerate(headers, start=1):
    cell = ws.cell(row=1, column=col_num, value=header)
    cell.border = border_style
    if col_num < 7:
        cell.font = header_input_style
        cell.fill = bg_green
    else:
        cell.font = header_output_style
        cell.fill = bg_red

# Get index of price columns
wholesale_price_index = headers.index("Wholesale Price (EUR)")
srp_price_index = headers.index("SRP (EUR)")

# Write data with styling
for row_num, row in enumerate(output_rows, start=2):
    for col_num, value in enumerate(row, start=1):
        cell = ws.cell(row=row_num, column=col_num)

        # Convert price columns to numbers (2 decimal places) or show "na"
        if col_num == wholesale_price_index + 1 or col_num == srp_price_index + 1:
            if value.lower() == "na":
                cell.value = value
            else:
                try:
                    cell.value = float(value)
                    cell.number_format = "0.00"  # Force 2 decimal places
                except ValueError:
                    cell.value = value
        else:
            cell.value = value

        # Apply styles
        cell.border = border_style
        if col_num < 7:
            cell.font = input_style
            cell.fill = bg_green
        else:
            cell.font = result_style
            cell.fill = bg_red

# Auto-adjust column widths
for col_num, column_cells in enumerate(ws.columns, start=1):
    max_length = max(len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells)
    ws.column_dimensions[get_column_letter(col_num)].width = max_length + 2

# Save the file
date_time_str = datetime.now().strftime("%d.%m.%Y")
file_name = f"Offwhite_And_Palmangels_Scrap_{date_time_str}.xlsx"
wb.save(file_name)

print(f"Created {file_name}")
