from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, NamedStyle
from openpyxl.utils import get_column_letter
from datetime import datetime

# Define headers and columns to keep
headers = ['Strike_id', 'Supplier SKU', 'Title', 'Brand', 'SKU', 'Barcode', 'Size', 'Colour Code', 'Colour', 'Present', 'Availability', 'Price (GBP)']
columns_to_keep = [header for header in headers if header != 'Strike_id']

# Read the data from 'output.txt'
output_rows = []
with open('output.txt', 'r') as f:
    lines = f.readlines()

# Skip rows starting with "SKU" and collect data
for line in lines:
    if line.strip().upper().startswith('SKU'):
        continue
    output_rows.append(line.strip().split('\t'))

# Create a new workbook and add a worksheet
wb = Workbook()
ws = wb.active
ws.title = "Summary"

# Define styles for headers and data
header_input_style = NamedStyle(name="header_input_style")
header_input_style.font = Font(name='Cambria', size=11, bold=True, color='006100')
header_input_style.fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
header_input_style.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

header_output_style = NamedStyle(name="header_output_style")
header_output_style.font = Font(name='Cambria', size=11, bold=True, color='9C0031')
header_output_style.fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
header_output_style.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

input_style = NamedStyle(name="input_style")
input_style.font = Font(name='Cambria', size=11, color='006100')
input_style.fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
input_style.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

result_style = NamedStyle(name="result_style")
result_style.font = Font(name='Cambria', size=11, color='9C0031')
result_style.fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
result_style.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

# Write headers with styles
for col_num, header in enumerate(columns_to_keep, start=1):
    cell = ws.cell(row=1, column=col_num, value=header)
    if col_num < 9:
        cell.style = header_input_style
    else:
        cell.style = header_output_style

# Write data rows with styles
row_num = 2
for row in output_rows:
    if len(row) != len(headers):  # Skip rows with incorrect column count
        continue

    # Remove the 'Strike_id' column and keep only columns_to_keep
    data_row = [row[headers.index(col)] for col in columns_to_keep]

    # Skip rows that are duplicate headers
    if data_row == columns_to_keep:
        continue

    for col_num, value in enumerate(data_row, start=1):
        cell = ws.cell(row=row_num, column=col_num)
        cell.value = value

        # Apply styles
        if col_num < 9:
            cell.style = input_style
        else:
            cell.style = result_style

    row_num += 1    

# Apply number format to 'Price (GBP)' column (2 decimal places)
price_column_index = columns_to_keep.index('Price (GBP)') + 1

for row_num in range(2, row_num):  # Start from row 2 since row 1 is the header
    cell = ws.cell(row=row_num, column=price_column_index)
    try:
        # Ensure the value is a number before applying the format
        cell.value = float(cell.value)
        cell.number_format = '0.00'  # 2 decimal places format
    except ValueError:
        pass  # If the value cannot be converted to float, leave it unchanged

# Auto-adjust column widths
for col_num, column_cells in enumerate(ws.columns, start=1):
    max_length = max(len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells)
    adjusted_width = max_length + 2
    ws.column_dimensions[get_column_letter(col_num)].width = adjusted_width

# Save the Excel file
date_time_str = datetime.now().strftime("%d.%m.%Y")
wb.save(f"Inspecs_Scrap_{date_time_str}.xlsx")
