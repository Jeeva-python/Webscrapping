from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, NamedStyle
from openpyxl.utils import get_column_letter
from datetime import datetime

# Read 'output.txt', skipping the first row
output_rows = []
with open('output.txt', 'r') as f:
    lines = f.readlines()

# Skip the first row if it contains headers
for line in lines[1:]:  # Skip the first row
    row_data = line.strip().split('\t')

    # Skip duplicate headers (if 'Sku' appears again)
    if row_data[0].strip().lower() == 'sku':
        continue

    output_rows.append(row_data)

# Define headers and columns to be kept
headers = ['Strike_id', 'Sku', 'site_sku', 'Brand', 'Name', 'Color Code', 'Barcode', 'Size', 'Prod URL', 
           'Present', 'Availability', 'Retail Price', 'Confidential Price (GBP)']
columns_to_keep = [header for header in headers if header not in ['Strike_id', 'Prod URL']]

# Create a new workbook
wb = Workbook()
ws = wb.active
ws.title = "Summary"

# Define header styles
header_input_style = NamedStyle(name="header_input_style")
header_input_style.font = Font(name='Cambria', size=11, bold=True, color='006100')
header_input_style.fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
header_input_style.border = Border(left=Side(style='thin'), right=Side(style='thin'),
                                   top=Side(style='thin'), bottom=Side(style='thin'))

header_output_style = NamedStyle(name="header_output_style")
header_output_style.font = Font(name='Cambria', size=11, bold=True, color='9C0031')
header_output_style.fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
header_output_style.border = Border(left=Side(style='thin'), right=Side(style='thin'),
                                    top=Side(style='thin'), bottom=Side(style='thin'))

# Define data styles
input_style = NamedStyle(name="input_style")
input_style.font = Font(name='Cambria', size=11, color='006100')
input_style.fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
input_style.border = Border(left=Side(style='thin'), right=Side(style='thin'),
                            top=Side(style='thin'), bottom=Side(style='thin'))

result_style = NamedStyle(name="result_style")
result_style.font = Font(name='Cambria', size=11, color='9C0031')
result_style.fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
result_style.border = Border(left=Side(style='thin'), right=Side(style='thin'),
                             top=Side(style='thin'), bottom=Side(style='thin'))

# Define price style (2 decimal places)
price_style = NamedStyle(name="price_style")
price_style.number_format = '0.00'
price_style.border = result_style.border
price_style.font = Font(name='Cambria', size=11, color='9C0031')
price_style.fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')

# Write headers with styles
for col_num, header in enumerate(columns_to_keep, start=1):
    cell = ws.cell(row=1, column=col_num, value=header)
    if col_num < 8:
        cell.style = header_input_style
    else:
        cell.style = header_output_style

# Find column indexes for formatting
confidential_price_index = columns_to_keep.index('Confidential Price (GBP)') + 1

# Write data rows with styles
row_num = 2
for row in output_rows:
    if len(row) != len(headers):  # Ensure row has correct number of columns
        continue

    # Extract only the required columns
    data_row = [row[headers.index(col)] for col in columns_to_keep]

    # Skip rows that are duplicate headers
    if data_row == columns_to_keep:
        continue

    for col_num, value in enumerate(data_row, start=1):
        cell = ws.cell(row=row_num, column=col_num)
        
        # Convert 'Confidential Price (GBP)' to float and apply number format
        if col_num == confidential_price_index:
            try:
                cell.value = float(value)
                cell.style = price_style
            except ValueError:
                cell.value = value
                cell.style = result_style
        else:
            cell.value = value
            cell.style = input_style if col_num < 8 else result_style

    row_num += 1

# Auto-adjust column widths
for col_num, column_cells in enumerate(ws.columns, start=1):
    max_length = max(len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells)
    adjusted_width = max_length + 2
    ws.column_dimensions[get_column_letter(col_num)].width = adjusted_width

# Save the Excel file
date_time_str = datetime.now().strftime("%d.%m.%Y")
wb.save(f"Thelios_Scrap_{date_time_str}.xlsx")
