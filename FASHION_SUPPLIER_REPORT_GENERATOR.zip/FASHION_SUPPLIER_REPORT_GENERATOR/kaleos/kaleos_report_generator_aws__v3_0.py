from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment, NamedStyle
from openpyxl.utils import get_column_letter
from datetime import datetime

# Read data from the file
with open('output.txt', 'r') as f:
    outputs = f.readlines()

output_rows = []

# Process each line in the file
for output_line in outputs[1:]:  # Skip the header
    row = output_line.strip().split('\t')
    
    # Handle 'na' and empty cells
    if len(row) > 5 and row[5].lower() == 'na':
        row[5] = ""
    if len(row) > 6 and row[6].lower() == 'na':
        row[6] = ""
    
    # Handle missing values for last two columns
    if len(row) > 10 and not row[-1].strip():
        row[-1] = 'na'
    if len(row) > 11 and not row[-2].strip():
        row[-2] = 'na'
    
    output_rows.append(row)

# Define headers and columns to keep
headers = ['Strike_id', 'Sku', 'Brand', 'Name', 'Model no', 'ClrCode', 'Barcode', 'Size', 'Present', 'Availability', 'Availability Date', 'Wholesale Price', 'Retail Price']
columns_to_keep = headers[1:]  # Exclude 'Strike_id'

# Create a new workbook and add a worksheet
wb = Workbook()
ws = wb.active
ws.title = "Summary"

# Define styles
header_input_style = NamedStyle(name="header_input")
header_input_style.font = Font(name='Cambria', size=11, bold=True, color="006100")
header_input_style.fill = PatternFill(start_color="c6efce", end_color="c6efce", fill_type="solid")
header_input_style.border = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

header_output_style = NamedStyle(name="header_output")
header_output_style.font = Font(name='Cambria', size=11, bold=True, color="9c0031")
header_output_style.fill = PatternFill(start_color="ffc7ce", end_color="ffc7ce", fill_type="solid")
header_output_style.border = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

input_style = NamedStyle(name="input")
input_style.font = Font(name='Cambria', size=11, color="006100")
input_style.fill = PatternFill(start_color="c6efce", end_color="c6efce", fill_type="solid")
input_style.border = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

result_style = NamedStyle(name="result")
result_style.font = Font(name='Cambria', size=11, color="9c0031")
result_style.fill = PatternFill(start_color="ffc7ce", end_color="ffc7ce", fill_type="solid")
result_style.border = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

# Define number format for prices
decimal_style = NamedStyle(name="decimal_style", number_format="0.00")

# Register styles
for style in [header_input_style, header_output_style, input_style, result_style, decimal_style]:
    if style.name not in wb.named_styles:
        wb.add_named_style(style)

# Write headers with styles
for col_num, header in enumerate(columns_to_keep, start=1):
    cell = ws.cell(row=1, column=col_num, value=header)
    cell.style = header_input_style if col_num < 8 else header_output_style

# Write data rows with styles
for row_num, row in enumerate(output_rows, start=2):
    for col_num, value in enumerate(row[1:], start=1):  # Skip 'Strike_id'
        cell = ws.cell(row=row_num, column=col_num, value=value)
        
        # Apply styles
        if col_num < 8:
            cell.style = input_style
        else:
            cell.style = result_style
        
        # Convert and format prices for "Wholesale Price" and "Retail Price"
        if columns_to_keep[col_num - 1] in ['Wholesale Price', 'Retail Price']:
            try:
                if value.strip():  # If not empty, convert to float
                    cell.value = float(value.replace(',', '').strip())
                    cell.style = result_style  # Apply result style
                    cell.number_format = "0.00"  # Apply decimal style for number formatting
                else:  # If empty, apply result style even if the value is empty
                    cell.value = ''
                    cell.style = result_style  # Apply result style for empty cells
                    cell.number_format = "0.00"  # Ensure the number format still applies
            except ValueError:
                pass  # Keep original value if conversion fails

# Auto-adjust column widths
for col_num, col_name in enumerate(columns_to_keep, start=1):
    max_length = max(len(str(ws.cell(row=row_num, column=col_num).value or "")) for row_num in range(1, ws.max_row + 1))
    ws.column_dimensions[get_column_letter(col_num)].width = max_length + 2

# Save the Excel file
date_time_str = datetime.now().strftime("%d.%m.%Y")
file_name = f"Kaleos_Scrap_{date_time_str}.xlsx"
wb.save(file_name)
