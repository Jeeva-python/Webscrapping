from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, numbers
from datetime import datetime

# Read the data from 'output.txt'
with open('output.txt', 'r') as f:
    outputs = f.readlines()

output_rows = []
for output_line in outputs:
    if output_line.strip().upper().startswith('SKU'):
        continue
    output_rows.append(output_line.strip().split('\t'))

# Define headers and columns to keep
headers = ['Strike_id', 'Model', 'Vendor', 'Type', 'Sku', 'Site Sku', 'Barcode', 'Size', 
           'Color Code', 'Present', 'stock', 'sport_stock', 'sport_future_stock', 
           'Availability Status', 'Wholesale Price', 'Retail Price']
columns_to_keep = [header for header in headers if header not in ['Strike_id', 'Prod URL']]

# Filter out 'Strike_id' column
filtered_indices = [headers.index(col) for col in columns_to_keep]

# Create a new workbook and sheet
wb = Workbook()
ws = wb.active
ws.title = "Summary"

# Define styles
header_input_style = {
    "font": Font(name="Cambria", size=11, bold=True, color="006100"),
    "fill": PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"),
    "alignment": Alignment(vertical="top")
}
header_output_style = {
    "font": Font(name="Cambria", size=11, bold=True, color="9C0031"),
    "fill": PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"),
    "alignment": Alignment(vertical="top")
}
input_style = {
    "font": Font(name="Cambria", size=11, color="006100"),
    "fill": PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"),
    "alignment": Alignment(vertical="top")
}
result_style = {
    "font": Font(name="Cambria", size=11, color="9C0031"),
    "fill": PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"),
    "alignment": Alignment(vertical="top")
}
thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), 
                     top=Side(style='thin'), bottom=Side(style='thin'))

# Identify columns for formatting
wholesale_price_col = columns_to_keep.index("Wholesale Price") + 1
retail_price_col = columns_to_keep.index("Retail Price") + 1

# Write headers
for col_num, col_name in enumerate(columns_to_keep, start=1):
    cell = ws.cell(row=1, column=col_num, value=col_name)
    style = header_input_style if col_num <= 8 else header_output_style
    cell.font = style["font"]
    cell.fill = style["fill"]
    cell.alignment = style["alignment"]
    cell.border = thin_border  # Apply border

# Write data rows
for row_num, output_line in enumerate(output_rows[1:], start=2):  # Skip first row to match df.drop(index=0)
    for col_num, col_index in enumerate(filtered_indices, start=1):
        value = output_line[col_index]

        # Convert "Wholesale Price" & "Retail Price" to float (if possible) and format
        if col_num in (wholesale_price_col, retail_price_col):
            try:
                value = float(value)
            except ValueError:
                pass  # Keep as string if conversion fails

        cell = ws.cell(row=row_num, column=col_num, value=value)
        style = input_style if col_num <= 8 else result_style
        cell.font = style["font"]
        cell.fill = style["fill"]
        cell.alignment = style["alignment"]
        cell.border = thin_border  # Apply border

        # Apply number format for price columns
        if col_num in (wholesale_price_col, retail_price_col):
            cell.number_format = numbers.FORMAT_NUMBER_00  # 2 decimal places

# Auto-adjust column width
for col in range(1, ws.max_column + 1):
    max_length = 0
    column_letter = ws.cell(row=1, column=col).column_letter  # Get column letter
    for row in ws.iter_rows(min_col=col, max_col=col, min_row=1, max_row=ws.max_row):
        for cell in row:
            try:
                max_length = max(max_length, len(str(cell.value)))
            except:
                pass
    ws.column_dimensions[column_letter].width = max_length + 2  # Adjust width

# Generate filename with current date
date_time_str = datetime.now().strftime("%d.%m.%Y")
filename = f"Youandsafilo_Scrap_{date_time_str}.xlsx"

# Save workbook
wb.save(filename)

print(f"Excel file '{filename}' has been created successfully.")
