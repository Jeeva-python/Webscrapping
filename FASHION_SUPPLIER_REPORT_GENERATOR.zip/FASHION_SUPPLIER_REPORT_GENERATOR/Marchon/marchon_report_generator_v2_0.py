from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Read the input data
outputs = []
COLUMNSTO_IGNORE = [8]

with open('output.txt', 'r') as f:
    outputs = f.readlines()

# Filter the required data
output_rows = []
for output_line in outputs:
    if output_line.strip().upper().startswith('SKU'):
        continue
    output_splits = output_line.strip().split('\t')
    updated_splits = []
    for i in range(0, len(output_splits)):
        if i + 1 not in COLUMNSTO_IGNORE:
            updated_splits.append(output_splits[i])
    output_rows.append(updated_splits)

# Create a new workbook and sheet
wb = Workbook()
ws = wb.active
ws.title = "Summary"

# Define column headers and formats
headers = ['SKU', 'Brand', 'Name', 'Color Code', 'Color', 'Barcode', 'Size', 'Present', 'Availability', 'Available By', 'Wholesale Price (GBP)', 'Seller Price (GBP)']
header_input_format = Font(name='Cambria', size=11, color="006100", bold=True)
header_output_format = Font(name='Cambria', size=11, color="9c0031", bold=True)
input_format = Font(name='Cambria', size=11, color="006100")
result_format = Font(name='Cambria', size=11, color="9c0031")

green_fill = PatternFill(start_color="c6efce", end_color="c6efce", fill_type="solid")
red_fill = PatternFill(start_color="ffc7ce", end_color="ffc7ce", fill_type="solid")
border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
alignment = Alignment(vertical='top')

# Set headers with formats
for col_num, value in enumerate(headers, 1):
    if col_num < 8:
        ws.cell(row=1, column=col_num, value=value).font = header_input_format
        ws.cell(row=1, column=col_num).fill = green_fill
    else:
        ws.cell(row=1, column=col_num, value=value).font = header_output_format
        ws.cell(row=1, column=col_num).fill = red_fill
    ws.cell(row=1, column=col_num).border = border
    ws.cell(row=1, column=col_num).alignment = alignment

# Write the rows of data
for row_num, row in enumerate(output_rows, 2):
    for i, val in enumerate(row):
        cell = ws.cell(row=row_num, column=i + 1, value=val)
        if i < 7:
            cell.font = input_format
            cell.fill = green_fill
        else:
            cell.font = result_format
            cell.fill = red_fill
        cell.border = border
        cell.alignment = alignment

        # Format 'Wholesale Price (GBP)' and 'Seller Price (GBP)' as numbers with 2 decimal places
        if i == 10 or i == 11:  # These columns correspond to 'Wholesale Price (GBP)' and 'Seller Price (GBP)'
            try:
                cell.value = float(val)
                cell.number_format = '0.00'  # 2 decimal places
            except ValueError:
                pass  # Skip non-numeric values

# Adjust column widths to fit the max content length
for col_num in range(1, len(headers) + 1):
    max_length = 0
    column = get_column_letter(col_num)
    
    for row in ws.iter_rows(min_col=col_num, max_col=col_num):
        for cell in row:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(cell.value)
            except:
                pass
    adjusted_width = (max_length + 2)  # Add some padding to the width
    ws.column_dimensions[column].width = adjusted_width

# Save the file with a timestamped name
date_time_str = datetime.now().strftime("%d.%m.%Y")
file_name = "Marchon_Scrap_" + date_time_str + ".xlsx"
wb.save(file_name)

print(f"Excel file saved as {file_name}")
