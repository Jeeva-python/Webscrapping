from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter
from datetime import datetime

# Read data from the file and ignore the first row
with open('output.txt', 'r') as f:
    outputs = f.readlines()[1:]  # Skip the first row

# Process data and filter out headers
output_rows = []
for output_line in outputs:
    output_splits = output_line.strip().split('\t')
    output_rows.append(output_splits)

# Define headers and remove "Strike_id" & "URL"
headers = [
    'Strike_id', 'Sku', 'Brand', 'Name', 'Model', 'Color_code', 'Barcode',
    'Manufacturer', 'Size', 'URL', 'Present', 'Stock Status', 'Availability',
    'Wholesale Price (EUR)', 'Seller Price (GBP)'
]
columns_to_keep = [header for header in headers if header not in ['Strike_id', 'URL']]

# Get column indexes for "Wholesale Price (EUR)" and "Seller Price (GBP)"
wholesale_index = columns_to_keep.index("Wholesale Price (EUR)")
seller_price_index = columns_to_keep.index("Seller Price (GBP)")

# Create a new workbook and worksheet
wb = Workbook()
ws = wb.active
ws.title = "Summary"

# Define border style
thin_border = Border(left=Side(style="thin"), right=Side(style="thin"),
                     top=Side(style="thin"), bottom=Side(style="thin"))

# Define header styles
header_input_style = {
    "font": Font(name='Cambria', size=11, bold=True, color="006100"),
    "fill": PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"),
    "border": thin_border,
    # "alignment": Alignment(horizontal="center", vertical="center")
}
header_output_style = {
    "font": Font(name='Cambria', size=11, bold=True, color="9C0031"),
    "fill": PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"),
    "border": thin_border,
    # "alignment": Alignment(horizontal="center", vertical="center")
}

# Define cell styles
input_style = {
    "font": Font(name='Cambria', size=11, color="006100"),
    "fill": PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"),
    "border": thin_border,
    "alignment": Alignment(horizontal="left", vertical="center")
}
output_style = {
    "font": Font(name='Cambria', size=11, color="9C0031"),
    "fill": PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"),
    "border": thin_border,
    "alignment": Alignment(horizontal="right", vertical="center")
}

# Write headers with styles
for col_num, header in enumerate(columns_to_keep, start=1):
    cell = ws.cell(row=1, column=col_num, value=header)
    
    # Apply header color based on column type
    if col_num <= 8:  # First 8 columns (Input data)
        cell.font = header_input_style["font"]
        cell.fill = header_input_style["fill"]
    else:  # Remaining columns (Results)
        cell.font = header_output_style["font"]
        cell.fill = header_output_style["fill"]

    cell.border = header_input_style["border"]
    # cell.alignment = header_input_style["alignment"]

# Write data rows with styles
for row_num, row in enumerate(output_rows, start=2):
    filtered_row = [row[i] for i in range(len(headers)) if headers[i] in columns_to_keep]  # Remove unwanted columns

    for col_num, value in enumerate(filtered_row, start=1):
        cell = ws.cell(row=row_num, column=col_num, value=value.strip() if value else "")

        # Determine the correct style for the cell
        if col_num <= 8:  # First 8 columns
            cell.font = input_style["font"]
            cell.fill = input_style["fill"]
            cell.alignment = input_style["alignment"]
        else:  # Remaining columns
            cell.font = output_style["font"]
            cell.fill = output_style["fill"]
            cell.alignment = output_style["alignment"]

        # Format "Wholesale Price (EUR)" and "Seller Price (GBP)" to 2 decimal places
        if col_num - 1 == wholesale_index or col_num - 1 == seller_price_index:
            try:
                cell.value = float(value)  # Convert to float
                cell.number_format = '0.00'  # Apply 2 decimal places
            except ValueError:
                pass  # Keep as text if conversion fails

        cell.border = thin_border  # Apply border

# Auto-adjust column widths
for col_num, column_cells in enumerate(ws.columns, start=1):
    max_length = max((len(str(cell.value)) if cell.value else 0) for cell in column_cells)
    adjusted_width = max(max_length + 2, 10)  # Minimum width 10
    ws.column_dimensions[get_column_letter(col_num)].width = adjusted_width

# Save the Excel file
date_time_str = datetime.now().strftime("%d.%m.%Y")
file_name = f"Kering_Scrap_{date_time_str}.xlsx"
wb.save(file_name)

print(f"Excel file '{file_name}' created successfully!")
