input_file = open("input1.txt","r")
Allines = input_file.readlines()
input_file.close()
tab_content = "\t".join(line.strip()for line in Allines)
output_file = open("output1.txt","w")
output_file.write(tab_content)
output_file.close()



