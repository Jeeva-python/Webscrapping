input_file = open("input.txt","r")
Allines = input_file.readlines()
output_file = open("output","w")
for item in Allines:
    if len(item) >= 4:
        print(len)
        columns = item.split("/t")
        str_id = columns[1]
        Domain = columns[3]
        output = output_file.writelines(Domain)