from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import requests
import os
import time

chrome_path = os.getenv('chrome')
service = Service(chrome_path + "/chromedriver.exe")
options = webdriver.ChromeOptions()
options.binary_location = chrome_path + "/chrome.exe"

web_driver = webdriver.Chrome(service = service,options = options)
web_driver.maximize_window()

def get_data(url):  
    web_driver.get(url)
    time.sleep(3)
    response = requests.get(url)
    soup = BeautifulSoup(response.text,"html.parser")
    # print(response.text)

    Brand = web_driver.find_element(By.CSS_SELECTOR,"#poExpander > div.a-expander-content.a-expander-partial-collapse-content > div > table > tbody > tr.a-spacing-small.po-brand > td.a-span9 > span")
    Mpn = None
    Asin = web_driver.find_element(By.CSS_SELECTOR,"#productDetails_detailBullets_sections1 > tbody > tr:nth-child(1) > td")
    return f"Brand: {Brand.text}""\n"f"Mpn: {Mpn}""\n"f"Asin: {Asin.text}"
url = "https://www.amazon.com/HP-Convertible-Processor-15-eu1026nr-Nightfall/dp/B09TG9G5JJ/ref=pd_rhf_gw_s_pd_sbs_rvi_d_sccl_1_3/133-9882197-4178617?pd_rd_w=Wl9bo&content-id=amzn1.sym.d5318d7f-f25b-4b36-88ea-c8d538d27fdf&pf_rd_p=d5318d7f-f25b-4b36-88ea-c8d538d27fdf&pf_rd_r=7P9P2PTFS3H589Y8S46E&pd_rd_wg=L9kpI&pd_rd_r=5c7a9b84-dfcd-409a-a7c4-2712a64c25b3&pd_rd_i=B09TG9G5JJ&psc=1"
print(get_data(url))
web_driver.quit()