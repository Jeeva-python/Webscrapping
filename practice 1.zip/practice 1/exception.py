# try:
#     input_file = open("input1.txt","r")
#     try:
#         input_file.writelines("this is write line")
#     finally:
#         print("this is finally")
# except Exception as ex:
#     print(ex)
# else:
#     print("file is successfully")
#     input_file.close()

# a=10
# b=0
# try:
#     print(a/b)
# except Exception:
#     print("Exception")
# finally:
#     print("this is finally block")

# class MyException(Exception):
#    "Invalid marks"
#    pass
   
# num = 10
# try:
#    if num <0 or num>100:
#       raise MyException
# except MyException as e:
#    print ("Invalid marks:", num)
# else:
#    print ("Marks obtained:", num)
  