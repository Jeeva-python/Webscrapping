# import logging

# logging.basicConfig(filename="logs.txt",filemode="w",level=logging.ERROR)



# logging.debug('This is a debug message')
# logging.info('This is an info message')
# logging.warning('This is a warning message')
# logging.error('This is an error message')
# logging.critical('This is a critical message')

import logging

logging.basicConfig(format='%(asctime)s %(message)s', level=logging.INFO)
marks = 120
logging.error("Invalid marks:{} Marks must be between 0 to 100".format(marks))
subjects = ["Phy", "Maths", "geography"]
logging.warning("Number of subjects: {}. Should be at least three".format((len(subjects))))
