import os
import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

chrome_path = os.getenv('chrome')

service = Service(chrome_path + "/chromedriver.exe")
options = webdriver.ChromeOptions()
options.binary_location = chrome_path + "/chrome.exe"
options.page_load_strategy = 'none'
web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

url ="https://www.tutorialspoint.com/python/python_operators.htm"
web_driver.get(url)
time.sleep(10)

login_button_element = web_driver.find_element(By.CSS_SELECTOR,'li.nav__item.nav__item--button')
login_button_element.click()
time.sleep(10)
