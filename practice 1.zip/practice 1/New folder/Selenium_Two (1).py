import os
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

chrome_path = os.getenv('chrome')
service = Service(chrome_path + "/chromedriver.exe")
options = webdriver.ChromeOptions()
options.binary_location = chrome_path + "/chrome.exe"
web_driver = webdriver.Chrome(service = service,options = options)
web_driver.maximize_window()

url = "https://defender.com/en_us/furuno-drs6ax-x-class-uhd-radar-base-and-antennas"
web_driver.get(url)

combo_box = web_driver.find_element(By.CSS_SELECTOR,"#attribute493")
combo_box.click()
options = combo_box.find_elements(By.CSS_SELECTOR,"option")

size_in = "4'"


for item in options:
    print(item.text)
    parts = item.text.split("-")

    if len(parts)<2:
        continue

    size = parts[0].strip()
    print(size)
    price = parts[1].strip()
    print(price)
    if size==size_in:
        print("Match Found")
        item.click()

        print(f"Price={price}")

        break

time.sleep(2)








