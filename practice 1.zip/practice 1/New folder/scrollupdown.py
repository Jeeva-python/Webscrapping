import os
import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

chrome_path = os.getenv('chrome')
service = Service(chrome_path + "/chromedriver.exe")
options = webdriver.ChromeOptions()
options.binary_location = chrome_path + "/chrome.exe"

web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

web_driver.get("https://www.tutorialspoint.com/index.htm")

# down
web_driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
time.sleep(2)

# top
web_driver.execute_script("window.scrollTo(0, 0);")
time.sleep(2)

web_driver.quit()
                                                                     