from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import os
import time

chrome_path = os.getenv('chrome')
service = Service(chrome_path + "/chromedriver.exe")
options = webdriver.ChromeOptions()
options.binary_location = chrome_path + "/chrome.exe"

web_driver = webdriver.Chrome(service = service,options = options)
web_driver.maximize_window()


def get_data(url):
    web_driver.get(url)
    time.sleep(3)

    brand_element = web_driver.find_element(By.CSS_SELECTOR, "#bd > div._1mlefwr0_6112._1mlefwr1_6112 > div.PdpLayoutResponsive-top > div > div.kzv0b81_6112.kzv0b86e_6112.kzv0b81eu_6112.kzv0b81gl_6112.kzv0b818s_6112.kzv0b81af_6112.kzv0b8wi_6112.kzv0b8y5_6112.kzv0b81yc_6112._2bxi2m3o_6112._2bxi2mb_6112._2bxi2m1t_6112._2bxi2m3p_6112 > div > div.StyledBox-owpd5f-0.BoxV2___StyledStyledBox-sc-1wnmyqq-0.iNfvtb > div:nth-child(1) > div > header > span > p > a")
    sku_element = web_driver.find_element(By.CSS_SELECTOR, "#bd > div._1mlefwr0_6112._1mlefwr1_6112 > div.PdpLayoutResponsive-breadcrumbWrap > nav > ol > li:nth-child(5) > span")
    Upc = None

    Brand = brand_element.text.replace("®","")

    Sku_text = sku_element.text
    
    if 'SKU:' in Sku_text:
        Sku = Sku_text.split('SKU:')[1].strip()

    return Brand, Upc, Sku

url = "https://www.wayfair.com/furniture/pdp/wade-logan-arfaan-tv-stand-for-tvs-with-electric-fireplace-included-w001384943.html?piid=941447219%2C959740916"
input_file = open("input.txt","r")
lines = input_file.readlines()

output_file = open("output.txt","w")
output_file.write("Brand\tUpc\tSku\n")
for item in lines:
        str01, url = item.strip().split('\t')
        Brand, Upc, Sku = get_data(url)
        output_file.write(f"{Brand}\t{Upc}\t{Sku}\n")
input_file.close()
output_file.close()
web_driver.close()

