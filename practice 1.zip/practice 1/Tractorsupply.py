from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import requests
import os
import time

chrome_path = os.getenv('chrome')
service = Service(chrome_path + "/chromedriver.exe")
options = webdriver.ChromeOptions()
options.binary_location = chrome_path + "/chrome.exe"

web_driver = webdriver.Chrome(service = service,options = options)
web_driver.maximize_window()

def get_data(url):  
    web_driver.get(url)
    time.sleep(3)
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    } 
    response = requests.get(url,headers=headers)
    print(response.text)
    soup = BeautifulSoup(response.text,"html.parser")

    Brand = web_driver.find_element(By.CSS_SELECTOR,"#breadcrumb_generic > ol > li:nth-child(5) > span")
    Sku = web_driver.find_elements(By.CSS_SELECTOR,"#container-4811137216 > div.aem-Grid.aem-Grid--12.aem-Grid--default--12 > div.responsivegrid.Pdp-Left-container.aem-GridColumn--default--none.aem-GridColumn.aem-GridColumn--default--6.aem-GridColumn--offset--default--0 > div > div.product-title.aem-GridColumn.aem-GridColumn--default--6 > div.product-title > div:nth-child(3) > div.component-wrapper.justify-content-between > div.d-flex.flex-row.align-items-center > div:nth-child(2)")
    for item in Sku:
        print(item.text)
    if Brand:
        Brand_list = Brand.text.split(" ")
        Brand_index = Brand_list[0]

    return f"Brand: {Brand_index}" "\n" f"Sku: {item.text}"
url = "https://www.tractorsupply.com/tsc/product/dewalt-1-2-in-drill-driver-kit-with-2-amp-hr-battery?cm_re=HP-_-Tile-_-Week+20-_-Power+Tools"
print(get_data(url))
web_driver.quit()