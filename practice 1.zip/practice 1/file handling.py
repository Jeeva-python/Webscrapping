# input_file = open("input.txt","w")
# # text = "this is input file to write"
# input_file.write("this is input file to write")
# input_file.close()

# input_file = open("input.txt","r")
# text = input_file.readlines()
# print(type(text))
# print(text)

input_file = open("input.txt", "w")
print("Name of the file: ", input_file.name)

input_file.write("This is new write")
input_file.writelines("this is new writelines")

str = "this is write line"
text = input_file.write(str)

str1 = "this is writelines"
text1 = input_file.writelines(str1)

input_file.close()



