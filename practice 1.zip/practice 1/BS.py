from bs4 import BeautifulSoup
import requests

def get_data(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text,"html.parser")
    # print(response)
    mpn = soup.select_one(".mpn")
    upc = soup.select_one("span.part-number > span[itemprop='gtin8']")
    brand = soup.select_one('#primaryProductNameStickyHeader')
    if brand:
        brand_list = brand.text.split()
        brand_index = brand_list[0]

    return f"mpn :{mpn.text}" "\n" f"upc :{upc.text}" "\n" f"brand :{brand_index}"

print(get_data("https://www.cdw.com/product/hp-p24h-g5-24-class-full-hd-lcd-monitor-16-9-black/7133847?origin=CDW&RecommendedForEDC=7442308"))
