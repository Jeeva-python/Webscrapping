from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import requests
import os
import time

chrome_path = os.getenv('chrome')
service = Service(chrome_path + "/chromedriver.exe")
options = webdriver.ChromeOptions()
options.binary_location = chrome_path + "/chrome.exe"

web_driver = webdriver.Chrome(service = service,options = options)
web_driver.maximize_window()

def get_data(url):  
    web_driver.get(url)
    time.sleep(3)
    response = requests.get(url)
    soup = BeautifulSoup(response.text,"html.parser")

    Brand = web_driver.find_element(By.CSS_SELECTOR,"#bh-app > section > div > div.container_DIOhDI0XlF.container_RiltKdop13 > div.name_RiltKdop13 > div.description_RiltKdop13 > div.title_RiltKdop13 > h1")
    Mpn = web_driver.find_element(By.CSS_SELECTOR,"#bh-app > section > div > div.container_DIOhDI0XlF.container_RiltKdop13 > div.name_RiltKdop13 > div.description_RiltKdop13 > div.meta_RiltKdop13 > div:nth-child(1) > div")
    
    if Brand:
        Brand_list = Brand.text.split()
        Brand_index = Brand_list[0]

        Mpn_list = Mpn.text
        Mpn_index = Mpn_list.replace("BH","CINECAM60KLFL").split(" ")
        Mpn_indexes = Mpn_index[0]

    return f"Brand: {Brand_index}""\n"f"Mpn: {Mpn_indexes}"
url = "https://www.bhphotovideo.com/c/product/1787634-REG/blackmagic_design_cinema_camera_6k.html"
print(get_data(url))
web_driver.quit()