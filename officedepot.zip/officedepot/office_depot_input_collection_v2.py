import os
import time
import json
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import undetected_chromedriver as uc
from selenium.common.exceptions import StaleElementReferenceException

# Configure logging
logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Console handler for logging
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logging.getLogger().addHandler(console_handler)

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = uc.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")

# Start undetected Chrome instance
web_driver = uc.Chrome(service=service, options=options)
web_driver.maximize_window()

# Identification file to track processed products
IDENTIFICATION_FILE = 'identification.txt'

def update_identification_file(strike_id: str):
    """Logs the processed product ID to a file."""
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

def get_identification_value():
    """Retrieves the last processed product ID from the file."""
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]  # Extract the last processed ID
    return last_id

def extract_json_ld(driver):
    """Extracts JSON-LD data from the page source."""
    try:
        # Look for all <script> tags of type 'application/ld+json'
        json_ld_elements = driver.find_elements(By.XPATH, '//script[@type="application/ld+json"]')
        for element in json_ld_elements:
            try:
                json_ld_content = element.get_attribute('innerHTML')
                json_data = json.loads(json_ld_content)
                
                # Check if this JSON-LD contains the product data we're looking for
                if isinstance(json_data, dict) and json_data.get("@type") == "Product":
                    return json_data  # Return the product data JSON-LD if found
            except json.JSONDecodeError as e:
                logging.error(f"Error parsing JSON-LD: {e}")
    except Exception as e:
        logging.error(f"No JSON-LD found: {e}")
    return None

def check_sku_in_json_ld(driver, expected_mpn):
    """Checks the product page for the correct MPN (Manufacturer Part Number) by extracting JSON-LD data."""
    try:
        # Extract the JSON-LD from the page
        json_ld = extract_json_ld(driver)
        
        if json_ld:
            # Extract the MPN or SKU from the JSON-LD
            actual_mpn = json_ld.get("mpn")
            logging.info(f"Found MPN in JSON-LD: {actual_mpn}")
            
            if actual_mpn == expected_mpn:
                logging.info(f"MPN matched: {actual_mpn}")
                return driver.current_url  # Return the product URL if MPN matches
            else:
                logging.info(f"MPN did not match: {actual_mpn} vs {expected_mpn}")
        else:
            logging.info("No valid JSON-LD found on the page.")
    
    except Exception as e:
        logging.error(f"Error checking MPN on product page: {e}")

    return None  # Return None if no MPN match is found

def func(search_text: str, expected_mpn: str, driver):
    search_url = f"https://www.officedepot.com/a/search/?q={search_text}"
    logging.info(f"Searching for: {search_text} | MPN: {expected_mpn}")

    try:
        driver.get(search_url)
        logging.info(f"Page loaded: {search_url}")
        # Wait for the product elements to be present
        wait = WebDriverWait(driver, 20)
        product_elements = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'div.od-row.od-search-browse-products-vertical img.od-sku-image')))
        logging.info(f"Found {len(product_elements)} products on the search results page.")

        for index, product_element in enumerate(product_elements):
            try:
                logging.info(f"Processing product {index + 1} of {len(product_elements)}")
                # Ensure we are working with a fresh reference of the element
                product_elements = driver.find_elements(By.CSS_SELECTOR, 'div.od-row.od-search-browse-products-vertical img.od-sku-image')
                product_element = product_elements[index]  # Re-get the element

                # Use actions to click for more robust interaction
                actions = webdriver.ActionChains(driver)
                actions.move_to_element(product_element).click().perform()

                time.sleep(2)  # Wait for the product page to load

                product_url = driver.current_url

                # Now check for MPN match in the JSON-LD
                if check_sku_in_json_ld(driver, expected_mpn):
                    logging.info(f"MPN match found: {product_url}")
                    return product_url  # Return the product URL if MPN matches
                else:
                    logging.info(f"No MPN match for product {index + 1}")

            except StaleElementReferenceException as e:
                logging.error(f"Stale element reference for product {index + 1}. Retrying...: {e}")
                continue  # Retry the current iteration
            except Exception as e:
                logging.error(f"Error processing product {index + 1}: {e}")
                continue
            finally:
                driver.back()
                time.sleep(2)

    except Exception as e:
        logging.info(f"Could not find the sku: {e}")

    return None

def main(input_file, output_file):
    """Main function to read input, process products, and save output."""
    last_id = get_identification_value()  # Get the last processed ID
    logging.info(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    
    with open(input_file, 'r') as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    with open(output_file, 'a') as f:
        f.write("ID\tproduct_url\n")  # Write header once

        for index, input_record in enumerate(inputs, start=1):
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 8:
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()

            # Skip already processed IDs
            if strike_id in processed_ids:
                continue
            
            brand = input_splits[1].strip()
            sku = input_splits[2].strip()
            upc = input_splits[3].strip()
            title = input_splits[4].strip()
            price = input_splits[5].strip()
            prod_url = input_splits[6].strip()
            search_text = input_splits[7].strip()

            logging.info(f"Processing product {index} of {total_products}: {strike_id}")
            product_url = func(search_text, sku, web_driver)  
            
            if product_url:
                result_line = f"{strike_id}\t{product_url}\n"
                f.write(result_line)  # Write result immediately
                logging.info(f"Product URL found for strike ID: {strike_id} - {product_url}")
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")
            
            update_identification_file(strike_id)  # Log the processed ID
            f.flush()  # Flush after each write to ensure it's written immediately

    logging.info("All results written to output file.")
    print("All results written to output file.")

if __name__ == "__main__":
    last_id = get_identification_value()  
    print(f"Last identification value: {last_id}")
    main('input.txt', 'output.txt')
    web_driver.quit()
