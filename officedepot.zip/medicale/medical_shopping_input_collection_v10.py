import os
import logging
import json
import time
import re
from datetime import datetime
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException

# Configure logging
logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logging.getLogger().addHandler(console_handler)

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = webdriver.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")

web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

IDENTIFICATION_FILE = 'identification.txt'
NOTFOUND_FILE = 'notfound.txt'

def update_identification_file(strike_id: str):
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

def get_identification_value():
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]
    return last_id

def record_not_found(input_id):
    """ Log the input_id (from the first column) that was not found to notfound.txt """
    with open(NOTFOUND_FILE, "a") as nf:
        nf.write(f"{input_id}\n")
    logging.info(f"Recorded input_id {input_id} to notfound.txt")

def func(search_text: str, expected_mpn: str, expected_upc: str, expected_gtin: str, driver):
    search_url = f"https://www.medicaleshop.com/search?q={search_text}"
    logging.info(f"Searching for: {search_text} | MPN: {expected_mpn} | UPC: {expected_upc} | GTIN: {expected_gtin}")
    
    try:
        driver.get(search_url)
        time.sleep(3)
        wait = WebDriverWait(driver, 3)
        try:
            close_button = wait.until(EC.presence_of_element_located(
                (By.XPATH, '//*[@id="__next"]/div[1]/div/div/div[2]/div/button')
            ))
            close_button.click()
            logging.info("Pop-up closed.")
            time.sleep(2)
        except TimeoutException:
            logging.info("No pop-up appeared.")
        
        # Get all product elements
        product_elements = wait.until(EC.presence_of_all_elements_located(
            (By.CSS_SELECTOR, '[aria-label=" Product"]')
        ))
        logging.info(f"Found {len(product_elements)} products on the search results page.")

        for index in range(len(product_elements)):
            try:
                product_element = product_elements[index]
                logging.info(f"Attempting to click on product {index + 1}.")
                product_element.click()
                time.sleep(3)  # Allow the page to load

                # Wait for product details to load
                product_details = wait.until(EC.presence_of_all_elements_located(
                    (By.CSS_SELECTOR, 'div.mt-4.flex.flex-wrap.items-center.gap-2')
                ))

                if product_details:
                    first_element = product_details[0]

                    # Attempt to extract UPC
                    upc = None
                    try:
                        upc = first_element.find_element(By.XPATH, ".//span[contains(text(), 'UPC:')]/following-sibling::div").text.strip()
                        logging.info(f"Found UPC: {upc}")
                    except NoSuchElementException:
                        logging.warning("UPC element not found.")
                    
                    # Attempt to extract GTIN
                    gtin = None
                    try:
                        gtin = first_element.find_element(By.XPATH, ".//span[contains(text(), 'GTIN:')]/following-sibling::div").text.strip()
                        logging.info(f"Found GTIN: {gtin}")
                    except NoSuchElementException:
                        logging.warning("GTIN element not found.")

                    # Clean and compare UPC
                    page_upc_cleaned = upc.lstrip('0').strip() if upc else None
                    input_upc_cleaned = expected_upc.lstrip('0').strip() if expected_upc != "na" else None
                    
                    # Clean and compare GTIN
                    page_gtin_cleaned = gtin.lstrip('0').strip() if gtin else None
                    input_gtin_cleaned = expected_gtin.lstrip('0').strip() if expected_gtin != "na" else None

                    logging.info(f"Comparing UPC: {page_upc_cleaned} with expected UPC: {input_upc_cleaned}")
                    logging.info(f"Comparing GTIN: {page_gtin_cleaned} with expected GTIN: {input_gtin_cleaned}")

                    # If UPC is available and matches, return the product URL
                    if expected_upc != "na" and page_upc_cleaned == input_upc_cleaned:
                        product_url = extract_product_url(driver)
                        if product_url:
                            logging.info(f"Product URL found via UPC: {product_url}")
                            return product_url
                    
                    # If GTIN is available and matches, return the product URL
                    if expected_gtin != "na" and page_gtin_cleaned == input_gtin_cleaned:
                        product_url = extract_product_url(driver)
                        if product_url:
                            logging.info(f"Product URL found via GTIN: {product_url}")
                            return product_url

                    # If UPC and GTIN are missing or not matching, attempt to match MPN
                    if (expected_upc == "na" or not upc) and (expected_gtin == "na" or not gtin):
                        logging.info("No UPC or GTIN found or matching. Attempting to match with MPN.")
                        
                        try:
                            mpn_from_page = first_element.find_element(By.XPATH, ".//span[contains(text(), 'MPN:')]/following-sibling::div").text.strip()
                            logging.info(f"Found MPN: {mpn_from_page}")

                            if mpn_from_page == expected_mpn:
                                product_url = extract_product_url(driver)
                                if product_url:
                                    logging.info(f"Product URL found via MPN: {product_url}")
                                    return product_url
                            else:
                                logging.warning(f"No matching UPC, GTIN, or MPN found. Expected MPN: {expected_mpn}, Found MPN: {mpn_from_page}")

                        except NoSuchElementException:
                            logging.warning("MPN element not found.")
    
                logging.warning("No product details found.")

            except StaleElementReferenceException:
                logging.warning("StaleElementReferenceException occurred, retrying to fetch product elements.")
                product_elements = wait.until(EC.presence_of_all_elements_located(
                    (By.CSS_SELECTOR, '[aria-label=" Product"]')
                ))
                continue  # Retry the current product
            except Exception as product_error:
                logging.error(f"Error processing product {index + 1}:", exc_info=True)
                continue

            finally:
                driver.back()
                time.sleep(2)  # Allow the page to load back

                # Re-fetch the product elements after navigating back
                product_elements = wait.until(EC.presence_of_all_elements_located(
                    (By.CSS_SELECTOR, '[aria-label=" Product"]')
                ))

    except Exception as e:
        logging.error(f"An error occurred in fetching products: {e}")

    return None

def extract_product_url(driver):
    """ Extracts the product URL from the current page. """
    script_tags = driver.find_elements(By.TAG_NAME, 'script')
    for script in script_tags:
        try:
            cleaned_script = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', script.get_attribute('innerHTML'))
            res = json.loads(cleaned_script)
            
            if isinstance(res, dict) and '@graph' in res:
                for item in res['@graph']:
                    if item.get('@type') == 'Product':
                        product_url = item.get('offers', {}).get('url')
                        if product_url:
                            return product_url.strip()  # Clean up the URL if needed

        except json.JSONDecodeError as e:
            logging.error(f"JSON decode error")

    return None

def extract_product_url(driver):
    """ Extracts the product URL from the <meta property="og:url"> tag. """
    try:
        meta_tag = driver.find_element(By.XPATH, "//meta[@property='og:url']")
        product_url = meta_tag.get_attribute('content')
        if product_url:
            # Ensure the URL starts with https://
            if not product_url.startswith("https://"):
                product_url = "https://" + product_url.strip()  # Prepend https:// if missing
            return product_url.strip()  # Ensure the URL is clean
    except NoSuchElementException:
        logging.warning("Meta tag for product URL not found.")
    return None

# Update the main function as needed, no further changes needed for calling this function.
def main(input_file, output_file):
    last_id = get_identification_value()
    logging.info(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    
    with open(input_file, 'r', encoding="utf-8") as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    with open(output_file, 'a') as f:
        f.write("ID\tproduct_url\n")  # Write header once

        for index, input_record in enumerate(inputs, start=1):
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 8:
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()
            if strike_id in processed_ids:
                continue
            
            brand = input_splits[1].strip()
            mpn = input_splits[2].strip()
            upc = input_splits[3].strip()
            title = input_splits[4].strip()
            price = input_splits[5].strip()
            prod_url = input_splits[6].strip()
            search_text = input_splits[7].strip()

            logging.info(f"Processing product {index} of {total_products}: {strike_id}")
            product_url = func(search_text, mpn, upc, upc, web_driver)  # Pass expected_gtin appropriately
 
            if product_url:
                result_line = f"{strike_id}\t{product_url}\n"
                f.write(result_line)  # Write result immediately
                logging.info(f"Product URL found for strike ID: {strike_id} - {product_url}")
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")
                record_not_found(strike_id)

            update_identification_file(strike_id)
            f.flush()

    logging.info("All results written to output file.")
    print("All results written to output file.")

if __name__ == "__main__":
    last_id = get_identification_value()  
    print(f"Last identification value: {last_id}")
    main('input.txt', 'output.txt')
    web_driver.quit()
