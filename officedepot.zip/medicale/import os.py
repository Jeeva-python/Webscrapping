import os
import time
import logging
import requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Define paths
chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = Options()
options.binary_location = os.path.join(chrome_path, "chrome.exe")

# Initialize WebDriver
web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

all_products = []

def get_product_urls(search_text: str):
    search_url = f"https://www.medicaleshop.com/search?q={search_text}"
    logging.info(f"Constructed URL {search_url}")
    
    # Wait for the page to load fully (wait for a specific element to load)
    try:
        WebDriverWait(web_driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'a[aria-label=" Product"]'))
        )
    except Exception as e:
        print(f"Error loading page: {e}")
        return []

    # Find all product links
    products = web_driver.find_elements(By.CSS_SELECTOR, 'a[aria-label=" Product"]')

    # Extract the href attribute (URL) from each product link
    for product in products:
        product_url = product.get_attribute("href")
        all_products.append(product_url)

    return all_products

# Test the function
print(get_data("https://www.medicaleshop.com/search?q=10658"))

# Optionally, close the browser after scraping
web_driver.quit()