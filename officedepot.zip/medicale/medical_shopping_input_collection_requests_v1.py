import os
import time
import logging
import requests
import json
from bs4 import BeautifulSoup
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Configure logging
logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logging.getLogger().addHandler(console_handler)

IDENTIFICATION_FILE = 'identification.txt'
NOTFOUND_FILE = 'notfound.txt'
all_products = []

chrome_path = os.getenv('chrome')  # Ensure this is set or update path manually
if not chrome_path:
    logging.error("Chrome path environment variable is not set. Please specify the path.")
    exit(1)

service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = Options()
options.binary_location = os.path.join(chrome_path, "chrome.exe")

# Initialize WebDriver
def init_web_driver():
    web_driver = webdriver.Chrome(service=service, options=options)
    web_driver.maximize_window()
    return web_driver

# Update identification file with the strike ID and current timestamp
def update_identification_file(strike_id: str):
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

# Get last processed identification value
def get_identification_value():
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]
    return last_id

# Record not found products to the notfound.txt file
def record_not_found(input_id):
    with open(NOTFOUND_FILE, "a") as nf:
        nf.write(f"{input_id}\n")
    logging.info(f"Recorded input_id {input_id} to notfound.txt")

# Get product URLs based on search text from the website
def get_product_urls(driver, search_text: str):
    search_url = f"https://www.medicaleshop.com/search?q={search_text}"
    logging.info(f"Constructed URL {search_url}")
    
    # Open the URL
    driver.get(search_url)
    
    # Wait for the page to load fully (wait for a specific element to load)
    try:
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'a[aria-label=" Product"]'))
        )
    except Exception as e:
        logging.error(f"Error loading page: {e}")
        return []

    # Find all product links
    products = driver.find_elements(By.CSS_SELECTOR, 'a[aria-label=" Product"]')

    # Extract the href attribute (URL) from each product link
    product_urls = [product.get_attribute("href") for product in products]
    return product_urls

# Fetch MPNs from the input file
def get_mpns_from_file(file_path):
    mpns = set()
    upcs = set()
    with open(file_path, 'r') as file:
        for line in file:
            parts = line.split("\t")
            if len(parts) >= 4:
                mpn = parts[2].strip() 
                upc = parts[3].strip() 
                mpns.add(mpn.lstrip('0')) 
                upcs.add(upc.lstrip('0')) 
    return mpns, upcs

# Extract product data from the page and match UPC/GTIN/MPN
def get_data(url, mpn, upc, mpns_from_file, upcs_from_file):
    data = {
        "mpn": "na",
        "GTIN": "na",
        "UPC": "na",
        "slug": "na",  # Added slug to capture the product slug
    }

    session = requests.Session()
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    }

    response = session.get(url, headers=headers)
    if response.status_code != 200:
        logging.error(f"Failed to fetch URL {url}")
        return None

    soup = BeautifulSoup(response.text, 'html.parser')

    script = soup.select_one('script#__NEXT_DATA__')
    if script:
        try:
            json_data = json.loads(script.string)
            apollo_state = json_data.get('props', {}).get('pageProps', {}).get('__APOLLO_STATE__', {})
            
            for key, value in apollo_state.items():
                if key.startswith("ProductType:") and isinstance(value, dict):
                    data['mpn'] = value.get('mpn', 'na')  # Extract 'mpn' field
                    data['GTIN'] = value.get('GTIN', 'na')
                    data['UPC'] = value.get('UPC', 'na')
                    data['slug'] = value.get('slug', 'na')  # Extract slug field
                    break
        except json.JSONDecodeError as e:
            logging.error(f"JSON Decode Error: {e}")
        except Exception as e:
            logging.error(f"Unexpected error: {e}")

    # Clean the UPC and GTIN before comparison
    page_upc_cleaned = data['UPC'].lstrip('0').strip() if data['UPC'] else None
    page_gtin_cleaned = data['GTIN'].lstrip('0').strip() if data['GTIN'] else None
    input_upc_cleaned = upc.lstrip('0').strip() if upc else None
    input_gtin_cleaned = None
    input_mpn_cleaned = mpn.strip() if mpn else None

    # Check if the UPC from the page matches the input UPC
    if upc != "na" and page_upc_cleaned == input_upc_cleaned:
        product_url = f"https://www.medicaleshop.com/{data['slug']}"  # Frame the product URL with slug
        logging.info(f"Product URL found via UPC: {product_url}")
        return product_url

    # Check if the GTIN from the page matches the input GTIN
    if page_gtin_cleaned == input_gtin_cleaned:
        product_url = f"https://www.medicaleshop.com/{data['slug']}"  # Frame the product URL with slug
        logging.info(f"Product URL found via GTIN: {product_url}")
        return product_url

    # Check if the MPN from the page matches the input MPN
    if input_mpn_cleaned in [data['mpn'], page_upc_cleaned, page_gtin_cleaned]:
        product_url = f"https://www.medicaleshop.com/{data['slug']}"  # Frame the product URL with slug
        logging.info(f"Product URL found via MPN: {product_url}")
        return product_url

    return None

# Main function to process the input file and get product URLs
def main(input_file, output_file):
    last_id = get_identification_value()
    logging.info(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    
    with open(input_file, 'r', encoding="utf-8") as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    # Initialize WebDriver
    driver = init_web_driver()

    # Open output file and write header once
    with open(output_file, 'a') as f:
        f.write("ID\tproduct_url\n")  # Write header

        for index, input_record in enumerate(inputs, start=1):
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 8:
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()
            if strike_id in processed_ids:
                continue
            
            brand = input_splits[1].strip()
            mpn = input_splits[2].strip()
            upc = input_splits[3].strip()
            title = input_splits[4].strip()
            price = input_splits[5].strip()
            prod_url = input_splits[6].strip()
            search_text = input_splits[7].strip()

            logging.info(f"Processing product {index} of {total_products}: {strike_id}")
            product_urls = get_product_urls(driver, search_text)
            matched_urls = []

            for url in product_urls:
                product_url = get_data(url, mpn, upc, None, None)  # Match product URL
                if product_url:
                    matched_urls.append(product_url)
                    logging.info(f"Match found: {product_url} for UPC: {upc}")

            # Only write to output if matched URLs are found
            if matched_urls:
                for url in matched_urls:
                    result_line = f"{strike_id}\t{url}\n"
                    f.write(result_line)  # Write result immediately
                logging.info(f"Matched URLs written for strike ID: {strike_id}")
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")

            update_identification_file(strike_id)
            f.flush()

    driver.quit()  # Quit the driver after processing
    logging.info("All results written to output file.")
    print("All results written to output file.")

if __name__ == "__main__":
    main('input.txt', 'output.txt')
