import logging
import requests
from bs4 import BeautifulSoup

# Initialize logging
logging.basicConfig(level=logging.INFO)

def get_data_with_headers(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    }

    try:
        # Make an HTTP request with headers
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            logging.info(f"HTTP request successful, status code: {response.status_code}")
        else:
            logging.error(f"Failed to retrieve the page, status code: {response.status_code}")
            return None

        # Parse the page content with BeautifulSoup
        soup = BeautifulSoup(response.text, 'html.parser')

        # First, check for SKU
        sku_element = soup.select_one('div[itemprop="sku"]')
        if sku_element:
            sku_text = sku_element.text.strip()
            logging.info(f"SKU found: {sku_text}")
        else:
            sku_text = "SKU not found"
            logging.info("SKU not found.")

        # Then, extract MPN (Model number)
        mpn_element = soup.select_one('product-model')
        if mpn_element:
            mpn_text = mpn_element.text.replace("Model #:", "").strip().replace('-', '')  # Clean MPN text
            logging.info(f"MPN found: {mpn_text}")
        else:
            mpn_text = "MPN not found"
            logging.info("MPN not found.")
        
        # Extract Product URL (from og:url meta tag)
        meta_url_element = soup.find('meta', attrs={'property': 'og:url'})
        if meta_url_element:
            product_url = meta_url_element.get('content')
            logging.info(f"Product URL found: {product_url}")
        else:
            product_url = "Product URL not found"
            logging.info("Product URL not found.")

        # Return the data
        return {
            "sku": sku_text,
            "mpn": mpn_text,
            "product_url": product_url
        }
    
    except requests.exceptions.RequestException as e:
        logging.error(f"Error during HTTP request: {e}")
        return None


# Example usage
url = "https://www.magidglove.com/uvex-astro-otg-3001-series-safety-glasses-with-ultra-dura-anti-scratch-coating-3001bkpp"
data = get_data_with_headers(url)

if data:
    logging.info(f"Extracted data: SKU: {data['sku']}, MPN: {data['mpn']}, Product URL: {data['product_url']}")
else:
    logging.error("Failed to extract product data.")
