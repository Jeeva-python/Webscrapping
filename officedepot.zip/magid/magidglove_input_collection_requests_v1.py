import os
import time
import logging
import requests
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Configure logging
logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Create a console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

# Add the console handler to the root logger
logging.getLogger().addHandler(console_handler)

# Chrome setup
chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = Options()
options.binary_location = os.path.join(chrome_path, "chrome.exe")
driver = webdriver.Chrome(service=service, options=options)

driver.maximize_window()

IDENTIFICATION_FILE = 'identification.txt'
NOTFOUND_FILE = "notfound.txt"
all_products = []

def update_identification_file(strike_id: str):
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

def get_identification_value():
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]
    return last_id

def record_not_found(input_id):
    with open(NOTFOUND_FILE, "a") as notfound:
        notfound.write(f"{input_id}\n")
        logging.info(f"Recorded input_id {input_id} to notfound.txt")

def get_product_urls(search_text: str):
    search_url = f"https://www.magidglove.com/search/?q={search_text}"
    logging.info(f"Constructed URL {search_url}")
        
    try:
        driver.get(search_url)
        print("Page Loaded")
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'a[itemprop="url"]'))
        )
        products = driver.find_elements(By.CSS_SELECTOR, 'a[itemprop="url"]')

        for product in products:
            product_url = product.get_attribute("href")
            if product_url:
                all_products.append(product_url)
                logging.info(f"Found product URL: {product_url}")

    except requests.exceptions.RequestException as e:
            logging.error(f"Error fetching search results for {search_text}: {e}")
        
    return all_products

def func(search_text: str, expected_mpn: str, driver):
    search_url = f"https://www.magidglove.com/search/?q={search_text}"
    logging.info(f"Searching for: {search_text} | Expected MPN: {expected_mpn}")

    try:
        # Go to the search URL
        driver.get(search_url)
        time.sleep(3)  # Wait for the page to load

        # Check if we're on a listing page or direct product page
        try:
            # Try to find a product link, meaning we're on a listing page
            product_element = driver.find_element(By.CSS_SELECTOR, 'div[itemprop="name"]')
            driver.execute_script("arguments[0].click();", product_element)
            time.sleep(3)  # Wait for the page to load after clicking
            logging.info(f"On a listing page, navigating to the first product link: {search_text}")
        except Exception as e:
            logging.info(f"Listing page error or not found, assuming we're on a direct product page.")
            # No need to click, we're on a direct product page already
            pass

        # Once we're on the product page, extract the product URL via SKU or MPN
        product_url = None

        # First, try to find the SKU and get the product URL from the meta tag
        try:
            sku_element = driver.find_element(By.CSS_SELECTOR, 'div[itemprop="sku"]')
            if sku_element:
                try:
                    # Look for meta tag with 'og:url' for the product URL
                    meta_url = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, 'meta[property="og:url"]'))
                    )
                    product_url = meta_url.get_attribute('content')
                    logging.info(f"Product URL found from SKU: {product_url}")
                except Exception as e:
                    logging.error(f"Error extracting product URL from SKU: {e}")
                    return None
        except Exception as e:
            logging.info("SKU not found, proceeding with MPN extraction.")

        # If SKU is not found, fall back to extracting MPN
        if not product_url:
            try:
                # Try to extract MPN from product page
                mpn_element = driver.find_element(By.CSS_SELECTOR, 'span.product-model')
                if mpn_element:
                    # Clean up the MPN text by removing unnecessary characters or information
                    mpn_text = mpn_element.text.replace("Model #:", "").strip().replace('-', '')  # Normalize MPN
                    logging.info(f"Extracted MPN text: {mpn_text}")

                    # Compare the cleaned-up MPN with the expected MPN (ignoring case and extra spaces)
                    if mpn_text.strip().lower() != expected_mpn.strip().lower():
                        logging.warning(f"MPN mismatch for {search_text}: Expected MPN: {expected_mpn.strip()}, Found MPN: {mpn_text.strip()}")
                        return None
                    else:
                        # If MPN matches, get the URL from the meta tag
                        try:
                            meta_url = WebDriverWait(driver, 10).until(
                                EC.presence_of_element_located((By.CSS_SELECTOR, 'meta[property="og:url"]'))
                            )
                            product_url = meta_url.get_attribute('content')
                            logging.info(f"Product URL found from MPN: {product_url}")
                        except Exception as e:
                            logging.error(f"Error extracting product URL from MPN: {e}")
                            return None
                else:
                    logging.warning(f"No MPN element found for: {search_text}")
                    return None
            except Exception as e:
                logging.error(f"Error extracting MPN from product page: {e}")
                return None

        # Return the found product URL (if any)
        if product_url:
            return product_url
        else:
            logging.warning(f"Product URL not found for: {search_text}")
            return None

    except Exception as e:
        logging.error(f"An error occurred while processing {search_text}: {e}")
        return None

def main(input_file, output_file):
    last_id = get_identification_value()  # Get the last processed ID
    logging.info(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    
    with open(input_file, 'r', encoding="utf-8", errors="ignore") as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    with open(output_file, 'a', encoding="utf-8", errors="ignore") as f:
        f.write("ID\tproduct_url\n")  # Write header once

        for index, input_record in enumerate(inputs, start=1):
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 8:
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()

            # Skip already processed IDs
            if strike_id in processed_ids:
                continue
            
            brand = input_splits[1].strip()
            mpn = input_splits[2].strip()  # Normalize MPN by removing dashes
            title = input_splits[4].strip()
            price = input_splits[5].strip()
            prod_url = input_splits[6].strip()
            search_text = input_splits[7].strip()   

            logging.info(f"Processing product {index} of {total_products}: {strike_id}")
            product_url = func(search_text, mpn, driver)  # Removed 'upc'

            if product_url:
                result_line = f"{strike_id}\t{product_url}\n"
                f.write(result_line)  # Write result immediately
                logging.info(f"Product URL found for strike ID: {strike_id} - {product_url}")
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")
                record_not_found(strike_id)

            update_identification_file(strike_id)  # Log the processed ID
            f.flush()  # Flush after each write to ensure it's written immediately

    logging.info("All results written to output file.")
    print("All results written to output file.")

if __name__ == "__main__":
    last_id = get_identification_value()  
    print(f"Last identification value: {last_id}")
    main('input.txt', 'output.txt')
