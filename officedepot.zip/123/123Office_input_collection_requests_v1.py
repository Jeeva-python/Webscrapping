import os
import time
import logging
import json
import requests
from bs4 import BeautifulSoup
from datetime import datetime

# Configure logging
logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Create a console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

# Add the console handler to the root logger
logging.getLogger().addHandler(console_handler)

IDENTIFICATION_FILE = 'identification.txt'
NOTFOUND_FILE = 'notfound.txt'

def update_identification_file(strike_id: str):
    """Updates the identification file with the processed strike ID."""
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

def get_identification_value():
    """Returns the last processed strike ID from the identification file."""
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]
    return last_id

def record_not_found(input_id):
    """Logs the input ID that was not found in the notfound.txt file."""
    with open(NOTFOUND_FILE, "a") as nf:
        nf.write(f"{input_id}\n")
    logging.info(f"Recorded input_id {input_id} to notfound.txt")

def get_product_urls(search_text: str):
    """Fetches product URLs based on the search text."""
    search_url = f"https://123office.com/search.php?search_query={search_text}&section=product"
    logging.info(f"Constructed URL {search_url}")
    
    try:
        response = requests.get(search_url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        
        # Extract product URLs from the page
        product_elements = soup.select('a.product-item-photo')
        product_urls = [a['href'] for a in product_elements if a['href'].startswith('http')]
        

        logging.info(f"Found {len(product_urls)} product URLs on the page.")
        
        return product_urls

    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching search results for {search_text}: {e}")
        return []

def get_product_details(url, expected_sku, expected_upc, expected_alt_upc):
    """Fetches product details and checks against expected values."""
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        
        # Extract JSON data or other attributes that contain product details
        script_tags = soup.find_all('script', type='text/javascript')
        for script in script_tags:
            if 'var BCData' in script.text:
                json_scr = script.text.split("= ")[1].split("};")[0] + "}"
                product_data = json.loads(json_scr)
                product_attributes = product_data.get('product_attributes', {})
                
                # Extract product details
                # sku = product_attributes.get('sku')
                # mpn = product_attributes.get('mpn')
                gtin = product_attributes.get('gtin')
                upc = product_attributes.get('upc')

                # Log extracted details for the product
                logging.info(f"Extracted details for {url}:")
                # logging.info(f"Expected SKU: {expected_sku} || Page SKU: {sku}")
                # logging.info(f"Expected MPN: {expected_sku} || Page MPN: {mpn}")
                logging.info(f"Expected GTIN: {expected_upc} || Page GTIN: {gtin}")
                logging.info(f"Expected UPC: {expected_upc} || Page UPC: {upc}")

                # Clean UPC, GTIN, and Alternate UPC to remove leading zeroes
                page_upc_cleaned = upc.lstrip('0') if upc else None
                page_gtin_cleaned = gtin.lstrip('0') if gtin else None
                input_upc_cleaned = expected_upc.lstrip('0')
                input_alt_upc_cleaned = expected_alt_upc.lstrip('0')

                # Check UPC and GTIN
                if page_upc_cleaned and page_upc_cleaned == input_upc_cleaned:
                    logging.info(f"UPC Matched, Found UPC {page_upc_cleaned} || Input UPC {input_upc_cleaned}")
                    return url
                elif page_gtin_cleaned and page_gtin_cleaned == input_upc_cleaned:
                    logging.info(f"GTIN Matched, Found GTIN {page_gtin_cleaned} || Input UPC {input_upc_cleaned}")
                    return url
                elif page_upc_cleaned and page_upc_cleaned == input_alt_upc_cleaned:
                    logging.info(f"UPC Matched (Alternate), Found UPC {page_upc_cleaned} || Alternate UPC {input_alt_upc_cleaned}")
                    return url
                elif page_gtin_cleaned and page_gtin_cleaned == input_alt_upc_cleaned:
                    logging.info(f"GTIN Matched (Alternate), Found GTIN {page_gtin_cleaned} || Alternate UPC {input_alt_upc_cleaned}")
                    return url

                # # If UPC, GTIN, and MPN are missing, check SKU
                # if not page_upc_cleaned and not page_gtin_cleaned and sku == expected_sku:
                #     logging.info(f"SKU Matched, Found SKU {sku} || Input SKU {expected_sku}")
                #     return url

    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching product details for {url}: {e}")
    
    return None

def func(search_text: str, expected_sku: str, expected_upc: str, expected_alt_upc: str):
    """Main function to process the search and check MPNs."""
    search_url = f"https://www.industrialsafetyproducts.com/search.php?search_query_adv={search_text}"
    logging.info(f"Searching for: {search_text}")
    product_urls = get_product_urls(search_text)
    matched_urls = []

    for url in product_urls:
        product_url = get_product_details(url, expected_sku, expected_upc, expected_alt_upc)
        if product_url:
            matched_urls.append(product_url)
            break

    return matched_urls

def main(input_file='input.txt', output_file='output.txt'):
    """Main function to read the input, check MPNs and write to output."""
    last_id = get_identification_value()  # Get the last processed ID
    logging.info(f"Last identification value: {last_id}")
    print(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    
    with open(input_file, 'r') as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    with open(output_file, 'a') as f:
        f.write("ID\tproduct_url\n")  # Write header once

        for index, input_record in enumerate(inputs, start=1):
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 8:
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()

            # Skip already processed IDs
            if strike_id in processed_ids:
                continue
            
            brand = input_splits[1].strip()
            sku = input_splits[2].strip()
            upc = input_splits[3].strip()
            alt_upc = input_splits[4].strip()
            title = input_splits[5].strip()
            price = input_splits[6].strip() 
            prod_url = input_splits[7].strip()
            search_text = input_splits[8].strip()
            

            logging.info(f"Processing product {index} of {total_products}: {strike_id}")
            matched_urls = func(search_text, sku, upc, alt_upc)
            
            if matched_urls:
                for product_url in matched_urls:
                    result_line = f"{strike_id}\t{product_url}\n"
                    f.write(result_line)  # Write result immediately
                    logging.info(f"Product URL found for strike ID: {strike_id} - {product_url}")
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")
                record_not_found(strike_id)
            
            update_identification_file(strike_id)  # Log the processed ID
            f.flush()

    logging.info("All results written to output file.")
    print("All results written to output file.")

if __name__ == "__main__":
    main()
