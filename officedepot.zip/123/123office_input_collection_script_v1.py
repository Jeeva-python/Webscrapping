import os
import time
import logging
import json
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup

# Configure logging
logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logging.getLogger().addHandler(console_handler)

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = webdriver.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")

web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

IDENTIFICATION_FILE = 'identification.txt'
NOTFOUND_FILE = "notfound.txt"

def update_identification_file(strike_id: str):
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

def get_identification_value():
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]
    return last_id

def record_not_found(input_id):
    with open(NOTFOUND_FILE, "a") as notfound:
        notfound.write(f"{input_id}\n")
        logging.info(f"Recorded input_id {input_id} to notfound.txt")

def extract_json_data(soup):
    script_elements = soup.find_all('script', type='text/javascript')
    for item in script_elements:
        if 'var BCData' in item.text:
            json_scr = item.text.split("= ")[1].split("};")[0] + "}"
            return json.loads(json_scr)
    return None

def extract_upc(scrap, search_text):
    upc = scrap.get('product_attributes', {}).get('upc')
    if upc is None:
        logging.warning(f"UPC not found in the JSON data for search text: {search_text}")
    return upc

def func(search_text: str, expected_sku: str, expected_upc: str, alternate_upc: str, driver):
    search_url = f"https://123office.com/search-results/?q={search_text}"
    logging.info(f"Searching for: {search_text} | SKU: {expected_sku} | UPC: {expected_upc} | Alternate UPC: {alternate_upc}")
    
    try:
        driver.get(search_url)
        time.sleep(5)
        WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, '#isp_search_results_container > li > div.isp_product_info > div.isp_product_sku')))
        logging.info("Page loaded, checking for SKU elements...")
        
        sku_elements = driver.find_elements(By.CSS_SELECTOR, '#isp_search_results_container > li > div.isp_product_info > div.isp_product_sku')
        onclick_elements = driver.find_elements(By.CSS_SELECTOR, "#isp_search_results_container > li > div.isp_product_info > a")

        if not sku_elements:
            logging.info(f"No SKU elements found for: {search_text}")
            return None

        for index, sku_element in enumerate(sku_elements):
            sku_value = sku_element.text.strip()
            logging.info(f"Found SKU: {sku_value}")

            if sku_value.lower() == expected_sku.lower():
                try:
                    if index < len(onclick_elements):  # Ensure the index is valid
                        onclick_elements[index].click()
                        time.sleep(5)
                        WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'meta[property="og:url"]')))

                        soup = BeautifulSoup(driver.page_source, 'html.parser')
                        scrap = extract_json_data(soup)
                        if not scrap:
                            logging.warning(f"No JSON data found for search text: {search_text}")
                            return None

                        # Extract UPC from the page
                        upc = extract_upc(scrap, search_text)
                        
                        # Strip leading zeros from both expected and alternate UPC, and the scraped UPC
                        upc_stripped = upc.lstrip('0').strip() if upc else ''
                        expected_upc_stripped = expected_upc.lstrip('0').strip()
                        alternate_upc_stripped = alternate_upc.lstrip('0').strip()

                        # Match either primary UPC or alternate UPC
                        if upc_stripped == expected_upc_stripped or upc_stripped == alternate_upc_stripped:
                            meta_url = driver.find_element(By.CSS_SELECTOR, 'meta[property="og:url"]')
                            if meta_url and meta_url.get_attribute('content'):
                                logging.info(f"Product URL found: {meta_url.get_attribute('content')}")
                                return meta_url.get_attribute('content')

                except Exception as click_error:
                    logging.warning(f"Click error: {click_error}. Retrying...")
                    time.sleep(5)
                    if index < len(onclick_elements):  # Ensure the index is valid
                        onclick_elements[index].click()
                        time.sleep(3)

                        soup = BeautifulSoup(driver.page_source, 'html.parser')
                        scrap = extract_json_data(soup)
                        if not scrap:
                            logging.warning(f"No JSON data found for search text: {search_text}")
                            return None

                        upc = extract_upc(scrap, search_text)

                        # Strip leading zeros from both expected and alternate UPC, and the scraped UPC
                        upc_stripped = upc.lstrip('0').strip() if upc else ''
                        expected_upc_stripped = expected_upc.lstrip('0').strip()
                        alternate_upc_stripped = alternate_upc.lstrip('0').strip()

                        # Match either primary UPC or alternate UPC
                        if upc_stripped == expected_upc_stripped or upc_stripped == alternate_upc_stripped:
                            meta_url = driver.find_element(By.CSS_SELECTOR, 'meta[property="og:url"]')
                            if meta_url and meta_url.get_attribute('content'):
                                logging.info(f"Product URL found: {meta_url.get_attribute('content')}")
                                return meta_url.get_attribute('content')

    except Exception as e:
        logging.error(f"An error occurred: {e}")

    return None

def main(input_file, output_file):
    last_id = get_identification_value()
    logging.info(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    with open(input_file, 'r') as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    with open(output_file, 'a') as f:
        f.write("ID\tproduct_url\n")  # Write header once

        for index, input_record in enumerate(inputs, start=1):
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 9:  # Ensure there are at least 9 columns
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()
            if strike_id in processed_ids:
                continue
            
            brand = input_splits[1].strip()
            sku = input_splits[2].strip()
            upc = input_splits[3].strip()
            alternate_upc = input_splits[4].strip()  # Get alternate UPC
            title = input_splits[5].strip()
            price = input_splits[6].strip()
            prod_url = input_splits[7].strip()
            search_text = input_splits[8].strip()

            logging.info(f"Processing product {index} of {total_products}: {strike_id}")
            product_url = func(search_text, sku, upc, alternate_upc, web_driver)  
            
            if product_url:
                result_line = f"{strike_id}\t{product_url}\n"
                f.write(result_line)
                logging.info(f"Product URL found for strike ID: {strike_id} - {product_url}")
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")
                record_not_found(strike_id)
                
            update_identification_file(strike_id)
            f.flush()

    logging.info("All results written to output file.")
    print("All results written to output file.")

if __name__ == "__main__":
    try:
        last_id = get_identification_value()  
        print(f"Last identification value: {last_id}")
        main('input.txt', 'output.txt')
    finally:
        web_driver.quit()
