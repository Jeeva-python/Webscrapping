import os
import time
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException

# Configure logging
logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Create a console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

# Add the console handler to the root logger
logging.getLogger().addHandler(console_handler)

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = webdriver.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")

web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

IDENTIFICATION_FILE = 'identification.txt'
NOTFOUND_FILE = 'notfound.txt'

def update_identification_file(strike_id: str):
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

def get_identification_value():
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]  
    return last_id

def record_not_found(input_id):
    """ Log the input_id (from the first column) that was not found to notfound.txt """
    with open(NOTFOUND_FILE, "a") as nf:
        nf.write(f"{input_id}\n")
    logging.info(f"Recorded input_id {input_id} to notfound.txt")

def func(search_text: str, expected_upc: str, driver):
    search_url = f"https://www.atcmedical.com/searchresults.aspx?keywords={search_text}"
    logging.info(f"Searching for: {search_text} | Expected UPC: {expected_upc}")

    # Remove leading zeros from the UPC for comparison
    expected_upc = expected_upc.lstrip('0') if expected_upc else ""
    logging.info(f"Expected UPC after stripping leading zeros: {expected_upc}")

    try:
        driver.get(search_url)
        time.sleep(2)  # Adding a sleep time here to allow the page to load

        # Wait for the nxt_image_wrapper elements to be present
        nxt_image_wrappers = WebDriverWait(driver, 10).until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.nxt_image_wrapper"))
        )
        logging.info(f"Found {len(nxt_image_wrappers)} products.")

        # Loop through each image wrapper
        for nxt_image_wrapper in nxt_image_wrappers:
            try:
                nxt_image_wrapper.click()
                logging.info("Clicked the product.")
               
                # Wait for the '.pl-extra-btn-col1' buttons to be present
                info_click_elements = WebDriverWait(driver, 10).until(
                    EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".pl-extra-btn-col1"))
                )

                # Loop through all matching elements and click each one using JavaScript
                for index, element in enumerate(info_click_elements):
                    try:
                        # Use JavaScript to click the button
                        driver.execute_script("arguments[0].click();", element)
                        logging.info(f"Clicked the show info.")
                                                
                        # Wait for the table with product data to load after clicking
                        product_lines = WebDriverWait(driver, 10).until(
                            EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'table#bodyContent_bodyContent_dlProductLines td.product-line-data'))
                        )
                        logging.info(f"Found {len(product_lines)} product lines after clicking the button.")
                       
                        # Loop through the product lines to check the UPC
                        for product_line in product_lines:
                            product_text = product_line.text.strip()
                            
                            logging.info(f"Extracted product line text: '{product_text}'")

                            # Check if the product text matches the expected UPC
                            if product_text and expected_upc in product_text:  # Check if expected UPC matches part of the text
                                logging.info(f"UPC match found: {product_text}")

                                # Try to find the product URL from the matching row
                                try:
                                    product_links = web_driver.find_elements(By.CSS_SELECTOR, 'link[rel="canonical"]')

                                    for link in product_links:
                                        # Log product URL regardless of MPN matching
                                        product_url = link.get_attribute('href')
                                        logging.info(f"Found product URL: {product_url}")

                                        # Navigate to the product page
                                        web_driver.get(product_url)
                                    return product_url
                                    
                                except NoSuchElementException:
                                    logging.error("Product URL element not found for this UPC match.")
                                    continue
                        logging.info("No matching UPC found in the product lines for this click.")
                        
                    except Exception as e:
                        logging.error(f"Error during processing of '.pl-extra-btn-col1' button click using JavaScript: {e}")
                        continue

                logging.info("No match found after clicking all '.pl-extra-btn-col1' buttons for this image wrapper.")
                
            except Exception as e:
                logging.error(f"Error during processing of image wrapper click: {e}")
                continue

            # If UPC doesn't match, go back to the search results and try the next product
            logging.info("UPC did not match. Going back to search results.")
            driver.back()
            time.sleep(2)  # Wait for the page to load again

        logging.info(f"No match found after clicking all image wrappers.")
        return None

    except TimeoutException as e:
        logging.error(f"TimeoutException occurred while processing: {e}")
        return None
    except WebDriverException as e:
        logging.error(f"WebDriverException occurred: {e}")
        return None
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")
        return None

def main(input_file, output_file):
    last_id = get_identification_value()  # Get the last processed ID
    logging.info(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    
    with open(input_file, 'r', encoding='utf-8', errors="replace") as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    with open(output_file, 'a') as f:
        f.write("ID\tproduct_url\n")  # Write header

        for index, input_record in enumerate(inputs, start=1):  # Start index at 1
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 8:
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()

            # Skip already processed IDs
            if strike_id in processed_ids:
                continue
            
            brand = input_splits[1].strip()
            sku = input_splits[2].strip()
            upc = input_splits[3].strip()
            title = input_splits[4].strip()
            price = input_splits[5].strip()
            prod_url = input_splits[6].strip()
            search_text = input_splits[7].strip()

            logging.info(f"Processing product {index} of {total_products}: {strike_id}")
            
            # Call func with only 3 arguments: search_text, upc, web_driver
            product_url = func(search_text, upc, web_driver)  
            
            if product_url:
                result_line = f"{strike_id}\t{product_url}\n"
                f.write(result_line)  # Write result immediately
                logging.info(f"Product URL found for strike ID: {strike_id} - {product_url}")
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")
                record_not_found(strike_id)

            update_identification_file(strike_id)  # Log the processed ID
            f.flush()  # Flush after each write to ensure it's written immediately

    logging.info("All results written to output file.")
    print("All results written to output file.")

if __name__ == "__main__":
    last_id = get_identification_value()  
    print(f"Last identification value: {last_id}")
    main('input.txt', 'output.txt')
    web_driver.quit()
