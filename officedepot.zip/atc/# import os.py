# import os
# import requests
# from bs4 import BeautifulSoup

# all_products = []

# def get_data(url: str):
#     # Send a GET request to the URL
#     response = requests.get(url)
    
#     # Check if the request was successful
#     if response.status_code == 200:
#         print(f"Successfully fetched page: {url}")
        
#         # Parse the HTML content with BeautifulSoup
#         soup = BeautifulSoup(response.text, "html.parser")
        
#         # Find all the product links on the page (adjust the selector as needed)
#         products = soup.select('a[aria-label="product name"]')  # Assuming 'a.product-details' is correct
        
#         # Extract the href attribute (URL) from each product link
#         for product in products:
#             product_url = product.get("href")
#             if product_url:
#                 all_products.append(product_url)
        
#         return all_products
#     else:
#         print(f"Failed to fetch page: {url}, Status code: {response.status_code}")
#         return []

# # Test the function
# print(get_data("https://www.atcmedical.com/searchresults.aspx?keywords=TideÂ® Pods, Laundry Detergent, Spring Meadow, 35 Pods/Pack, Each"))
import os
import time
import logging
import requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Define paths
chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = Options()
options.binary_location = os.path.join(chrome_path, "chrome.exe")

# Initialize WebDriver
web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

all_products = []

def get_data(url: str):
    # Open the URL in the browser
    web_driver.get(url)
    
    # Wait for the page to load fully (wait for a specific element to load)
    try:
        WebDriverWait(web_driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'a[aria-label="product name"]'))
        )
    except Exception as e:
        print(f"Error loading page: {e}")
        return []

    # Find all product links
    products = web_driver.find_elements(By.CSS_SELECTOR, 'a[aria-label="product name"]')

    # Extract the href attribute (URL) from each product link
    for product in products:
        product_url = product.get_attribute("href")
        all_products.append(product_url)

    return all_products

# Test the function
print(get_data("https://www.atcmedical.com/searchresults.aspx?keywords=TideÂ® Pods, Laundry Detergent, Spring Meadow, 35 Pods/Pack, Each"))

# Optionally, close the browser after scraping
web_driver.quit()