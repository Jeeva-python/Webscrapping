import os
import time
import logging
import requests

from bs4 import BeautifulSoup
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

logging.getLogger().addHandler(console_handler)

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = Options()
options.binary_location = os.path.join(chrome_path, "chrome.exe")

web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

IDENTIFICATION_FILE = 'identification.txt'
NOTFOUND_FILE = 'notfound.txt'
all_products = []

def update_identification_file(strike_id: str):
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

def get_identification_value():
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]  
    return last_id

def record_not_found(input_id):
    """ Log the input_id (from the first column) that was not found to notfound.txt """
    with open(NOTFOUND_FILE, "a") as nf:
        nf.write(f"{input_id}\n")
    logging.info(f"Recorded input_id {input_id} to notfound.txt")

def get_product_urls(search_text: str):
    search_url = f"https://www.atcmedical.com/searchresults.aspx?keywords={search_text}"
    logging.info(f"Constructed URL {search_url}")
    
    try:
        web_driver.get(search_url)
        print("Page Loaded")
        WebDriverWait(web_driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'a[aria-label="product name"]'))
        )

        products = web_driver.find_elements(By.CSS_SELECTOR, 'a[aria-label="product name"]')

        for product in products:
            product_url = product.get_attribute("href")
            if product_url:
                all_products.append(product_url)
                logging.info(f"Found product URL: {product_url}")

    except requests.exceptions.RequestException as e:
        
        logging.error(f"Error fetching search results for {search_text}: {e}")
    
    return all_products

def get_upcs_from_file(file_path):
    upcs = set()  
    with open(file_path, 'r') as file:
        for line in file:
            parts = line.split("\t")
            if len(parts) >= 4:
                upc = parts[3].strip()  
                upcs.add(upc.lstrip('0'))  
                print("upcs:", upcs)
    return upcs

def get_data(url, upcs_from_file):
    response = requests.get(url)
    
    if response.status_code != 200:
        logging.error(f"Failed to retrieve the page: {url}, status code: {response.status_code}")
        return None

    soup = BeautifulSoup(response.text, "html.parser")
    
    product_elements = soup.select("table#bodyContent_bodyContent_dlProductLines td.product-line-data")
    
    for item in product_elements:
        text = item.get_text(separator=" ", strip=True)
  
        details = text.split('Units per')  
    
        if len(details) > 1:
            product_info = details[0].strip()
            product_upc = extract_upc(product_info)
            
            if product_upc:
                product_upc = product_upc.lstrip('0')

            if product_upc and product_upc in upcs_from_file:
               
                product_url = soup.find("link", {"rel": "canonical"})['href']
                logging.info(f"Found product URL for UPC {product_upc}: {product_url}")
                return product_url

    return None

def extract_upc(text):
    # Find a 12-digit number in the text which corresponds to a UPC
    import re
    match = re.search(r'\b\d{12}\b', text)
    return match.group(0) if match else None

def func(search_text: str, expected_upc: str):
    logging.info(f"Searching for: {search_text}")
    product_urls = get_product_urls(search_text)  
    matched_urls = []

    for url in product_urls:
        product_url = get_data(url, expected_upc)  
        if product_url:  
            matched_urls.append(product_url)
            logging.info(f"Match found: {product_url} for UPC: {expected_upc}")
            return matched_urls  # Return matched URLs immediately, exiting the loop

    return matched_urls  # Return empty list if no match is found

def main(input_file='input.txt', output_file='output.txt'):
    last_id = get_identification_value() 
    logging.info(f"Last identification value: {last_id}")
    print(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    
    with open(input_file, 'r') as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    with open(output_file, 'a') as f:
        f.write("ID\tproduct_url\n")  

        for index, input_record in enumerate(inputs, start=1):
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 8:
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()

            if strike_id in processed_ids:
                continue  # Skip if already processed
    
            upc = input_splits[3].strip()
            search_text = input_splits[7].strip()

            logging.info(f"Processing product {index} of {total_products}: {strike_id}")
            matched_urls = func(search_text, upc)
            
            if matched_urls:  # If we have found a URL for this strike_id
                for product_url in matched_urls:
                    result_line = f"{strike_id}\t{product_url}\n"
                    f.write(result_line)  
                    logging.info(f"Product URL found for strike ID: {strike_id} - {product_url}")
                    break  # Exit after finding the first match for this strike_id
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")
                record_not_found(strike_id)
            
            update_identification_file(strike_id)  # Mark strike_id as processed
            f.flush()

    logging.info("All results written to output file.")
    print("All results written to output file.")

    web_driver.quit()

if __name__ == "__main__":
    main()
