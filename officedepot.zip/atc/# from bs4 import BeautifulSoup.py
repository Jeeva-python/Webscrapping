# from bs4 import BeautifulSoup
# import requests

# def get_data(url):
#     # Send the GET request to the URL
#     response = requests.get(url)
    
#     # Check if the request was successful
#     if response.status_code != 200:
#         return f"Failed to retrieve the page, status code: {response.status_code}"

#     # Parse the HTML response with BeautifulSoup
#     soup = BeautifulSoup(response.text, "html.parser")
    
#     # Initialize a list to store the product details
#     product_details = []

# # td.product-line-data>div>div.row-extra-line-info>div>span
    
#     # Use CSS selector to find all relevant elements
#     product_elements = soup.select("table#bodyContent_bodyContent_dlProductLines td.product-line-data")
    
#     # Loop through each element and get the text
#     for item in product_elements:
#         product_details.append(item.get_text(strip=True))  # Strip extra spaces and add to the list

#     # Return the extracted product details
#     return product_details

# # Test the function
# print(get_data("https://www.atcmedical.com/Aids_To_Daily_Living/Bathroom/628337/product.aspx"))


from bs4 import BeautifulSoup
import requests

def get_upcs_from_file(file_path):
    upcs = set()  # Use a set to avoid duplicates
    with open(file_path, 'r') as file:
        for line in file:
            parts = line.split("\t")
            if len(parts) >= 4:
                upcs.add(parts[3].strip())  # The UPC is in the 4th column (index 3)
                print("upcs:", upcs)
    return upcs

def get_data(url, upcs_from_file):
    # Send the GET request to the URL
    response = requests.get(url)
    
    # Check if the request was successful
    if response.status_code != 200:
        return f"Failed to retrieve the page, status code: {response.status_code}"

    # Parse the HTML response with BeautifulSoup
    soup = BeautifulSoup(response.text, "html.parser")
    
    # Initialize a list to store the matched UPCs
    matched_upcs = []

    # Use CSS selector to find all relevant elements for product details
    product_elements = soup.select("table#bodyContent_bodyContent_dlProductLines td.product-line-data")

    # Loop through each element and extract the relevant details
    for item in product_elements:
        # Get the text content of the product element and clean it
        text = item.get_text(separator=" ", strip=True)  # Clean text with space separation
        
        # Split the text into meaningful parts (e.g., Product Name, Model#, UPC, etc.)
        details = text.split('Units per')  # Assuming 'Units per' separates product info and price
    
        if len(details) > 1:
            product_info = details[0].strip()
            print("product_info:", product_info)  # This part should contain the product name, model#, and UPC
            # Assuming the UPC is in the product_info, extract it (e.g., by searching for 12-digit numbers)
            product_upc = extract_upc(product_info)
            
            # Check if this UPC is in the list from the file
            if product_upc and product_upc in upcs_from_file:
                matched_upcs.append(product_upc)
    
    # Return the matched UPCs
    return matched_upcs

def extract_upc(text):
    # Find a 12-digit number in the text which corresponds to a UPC
    import re
    match = re.search(r'\b\d{12}\b', text)
    return match.group(0) if match else None

# Read UPCs from the input.txt file
upcs_from_file = get_upcs_from_file("input.txt")

# Test the function by scraping data from the URL
url = "https://www.atcmedical.com/Aids_To_Daily_Living/Bathroom/628337/product.aspx"
matched_upcs = get_data(url, upcs_from_file)

# Print the matched UPCs
print("Matched UPCs:", matched_upcs)

                                                                                                