# import json
# from bs4 import BeautifulSoup
# import requests

# def get_data(url: str):
#     headers = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"}
#     response = requests.get(url,headers=headers)
#     print(response.status_code)
#     soup = BeautifulSoup(response.text, "html.parser")
#     script = soup.select_one('script[data-hypernova-key="SearchPage"]')
#     json_scr = script.text.strip("<!--").strip("-->")
        
#     res = json.loads(json_scr)


#     mpn = res.get('facetNavigation').get("productsCount")
#     gtin = res.get('mpn','N/A')
#         # brand = res.get('brand').get('name','N/A')
#     return f"mpn :{mpn}" "\n"  f"upc :{gtin}"         
       
# print(get_data("https://www.webstaurantstore.com/search/dial-17000122588.html")) 


import json
from bs4 import BeautifulSoup
import requests

def get_data(url: str):
    headers = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"}
    response = requests.get(url, headers=headers)
    print(response.status_code)
    soup = BeautifulSoup(response.text, "html.parser")
    script = soup.select_one('script[data-hypernova-key="SearchPage"]')
    json_scr = script.text.strip("<!--").strip("-->")
    
    res = json.loads(json_scr)
    
    # Extract product data from the json response
    products = res.get('products', [])
    
    # Iterate through the product list to fetch 'seoUpc' for each product
    upc_list = []
    for product in products:
        seo_upc = product.get('seoUpc', 'N/A')
        link = product.get("link")
        upc_list.append(seo_upc)
    
    # Join the UPC values into a string
    # upc_values = "\n".join(upc_list)
    
    return f"seo_upc :{upc_list}" "\n"  f"link : https://www.webstaurantstore.com/{link}"

print(get_data("https://www.webstaurantstore.com/search/dial-17000122588.html"))
