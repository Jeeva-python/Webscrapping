import os
import logging
import requests
import json
from datetime import datetime
from bs4 import BeautifulSoup

logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logging.getLogger().addHandler(console_handler)

IDENTIFICATION_FILE = 'identification.txt'
NOTFOUND_FILE = "notfound.txt"
input_file = 'input.txt'  
output_file = 'output.txt'  

def update_identification_file(strike_id: str):
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

def get_identification_value():
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]
    return last_id

def record_not_found(input_id):
    with open(NOTFOUND_FILE, "a") as notfound:
        notfound.write(f"{input_id}\n")
        logging.info(f"Recorded input_id {input_id} to notfound.txt")

def get_data(url: str, upc: str, alternate_upc: str):
    headers = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"}
    response = requests.get(url, headers=headers)
    logging.info(f"Fetching data from URL: {url} | Status Code: {response.status_code}")
    
    if response.status_code != 200:
        logging.error(f"Failed to fetch data from {url}. Status code: {response.status_code}")
        return None
    
    soup = BeautifulSoup(response.text, "html.parser")
    script = soup.select_one('script[data-hypernova-key="SearchPage"]')
    if not script:
        logging.error(f"Could not find script with data-hypernova-key in the page.")
        return None
    
    json_scr = script.text.strip("<!--").strip("-->")
    res = json.loads(json_scr)
    
    products = res.get('products', [])
    
    for product in products:
        seo_upc = product.get('seoUpc', 'N/A')
        link = product.get("link")

        # Clean and normalize UPCs before comparison
        upc = upc.lstrip('0').strip()
        alternate_upc = alternate_upc.lstrip('0').strip()
        seo_upc = seo_upc.lstrip('0').strip()

        logging.info(f"Comparing UPC: {seo_upc} with input UPC: {upc} or alternate UPC: {alternate_upc}")

        if seo_upc == upc or seo_upc == alternate_upc:
            if link and not link.startswith("http"):
                full_url = f"https://www.webstaurantstore.com{link}"
                logging.info(f"Found matching product with UPC {seo_upc}: {full_url}")
                return full_url
            
    logging.warning(f"No matching product found for UPC: {upc} or Alternate UPC: {alternate_upc}")
    return None

def func(search_text: str, upc: str, alternate_upc: str):
    """Search for products using search_text and match with UPC."""
    search_url = f"https://www.webstaurantstore.com/search/{search_text}.html"
    logging.info(f"Searching for: {search_text} | UPC: {upc} | Alternate UPC: {alternate_upc} url: {search_url}")

    try:
        response = requests.get(search_url)
        logging.info(f"Searching URL: {search_url} | Status Code: {response.status_code}")
        if response.status_code != 200:
            logging.error(f"Failed to retrieve search results for {search_text}. Status code: {response.status_code}")
            return None
        
        soup = BeautifulSoup(response.content, 'html.parser')
    except Exception as e:
        logging.error(f"An error occurred in fetching search page: {e}")
        return None

    # Get the link to the product page based on UPCs
    product_link = get_data(search_url, upc, alternate_upc)
    return product_link

def main(input_file, output_file):
    last_id = get_identification_value()
    logging.info(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    
    with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r', encoding='utf-8', errors='ignore') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    with open(output_file, 'a') as f:
        f.write("ID\tproduct_url\n")  # Write header once

        for index, input_record in enumerate(inputs, start=1):
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 8:
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()
            if strike_id in processed_ids:
                continue
            
            brand = input_splits[1].strip()
            mpn = input_splits[2].strip()
            upc = input_splits[3].strip()
            alternate_upc = input_splits[4].strip()
            title = input_splits[5].strip()
            price = input_splits[6].strip()
            prod_url = input_splits[7].strip()  # This is the input product URL
            search_text = input_splits[8].strip()

            logging.info(f"Processing product {index} of {total_products}: {strike_id}")
            product_url = func(search_text, upc, alternate_upc)  
            
            if product_url:
                result_line = f"{strike_id}\t{product_url}\n"
                f.write(result_line)  # Write result immediately
                logging.info(f"Product URL found for strike ID: {strike_id} - {product_url}")
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")
                record_not_found(strike_id)
                
            update_identification_file(strike_id)
            f.flush()

    logging.info("All results written to output file.")
    print("All results written to output file.")

if __name__ == "__main__":
    last_id = get_identification_value()  
    print(f"Last identification value: {last_id}")
    main('input.txt', 'output.txt')

