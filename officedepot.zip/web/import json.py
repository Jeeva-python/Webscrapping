import json
from bs4 import BeautifulSoup
import requests

def get_upcs_from_file(file_path):
    # Read UPCs and alternate UPCs from input.txt file
    upc_dict = {}
    with open(file_path, 'r') as file:
        for line in file:
            input_splits = line.strip().split("\t")
            
            if len(input_splits) >= 9:  # Ensure there are enough columns in the row
                upc = input_splits[3].strip()  # 4th column (index 3) is the regular UPC
                alternate_upc = input_splits[4].strip()  # 5th column (index 4) is the alternate UPC
                
                # Use both UPCs as keys, both pointing to the same product
                upc_dict[upc] = input_splits[5].strip()  # The 6th column (index 5) is the title/description (or whatever data you want to associate with the UPC)
                upc_dict[alternate_upc] = input_splits[5].strip()  # Same title for the alternate UPC as well
    return upc_dict

def get_data(url: str, upc_dict):
    headers = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"}
    response = requests.get(url, headers=headers)
    print(f"Status Code: {response.status_code}")
    
    if response.status_code != 200:
        return "Error: Unable to fetch the webpage"
    
    soup = BeautifulSoup(response.text, "html.parser")
    script = soup.select_one('script[data-hypernova-key="SearchPage"]')
    
    if not script:
        return "Error: Could not find product data in the page"
    
    json_scr = script.text.strip("<!--").strip("-->")
    
    try:
        res = json.loads(json_scr)
    except json.JSONDecodeError:
        return "Error: Failed to decode JSON data"
    
    # Extract product data from the json response
    products = res.get('products', [])
    
    matched_results = []
    for product in products:
        seo_upc = product.get('seoUpc', 'N/A')
        link = product.get("link")
        
        # Check if either the UPC or alternate UPC matches any of the entries in the dictionary
        if seo_upc in upc_dict:
            matched_results.append(f"seo_upc: {seo_upc}\nlink: https://www.webstaurantstore.com/{link}")
    
    if matched_results:
        return "\n".join(matched_results)
    else:
        return "No matching products found."

# Read UPCs from input.txt
upc_dict = get_upcs_from_file('input.txt')

# Fetch the data from the webpage and match UPCs
url = "https://www.webstaurantstore.com/search/dial-17000122588.html"
print(get_data(url, upc_dict))
