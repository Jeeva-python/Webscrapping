import os
import logging
import json
import time
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException

# Configure logging
logging.basicConfig(filename='applog.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logging.getLogger().addHandler(console_handler)

chrome_path = os.getenv('chrome')
service = Service(os.path.join(chrome_path, "chromedriver.exe"))
options = webdriver.ChromeOptions()
options.binary_location = os.path.join(chrome_path, "chrome.exe")

web_driver = webdriver.Chrome(service=service, options=options)
web_driver.maximize_window()

IDENTIFICATION_FILE = 'identification.txt'

def update_identification_file(strike_id: str):
    with open(IDENTIFICATION_FILE, "a") as identification_file:
        identification_file.write(f"{strike_id}\t{str(datetime.now())}\n")

def get_identification_value():
    logging.info(f"Opening identification file {IDENTIFICATION_FILE}")
    last_id = 'none'
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r') as f:
            lines = f.readlines()
            if lines:
                last_id = lines[-1].split('\t')[0]
    return last_id

def extract_json_ld(driver):
    """Extracts JSON-LD data from the page source."""
    try:
        # Look for all <script> tags of type 'application/ld+json'
        json_ld_elements = driver.find_elements(By.XPATH, '//script[@type="application/ld+json"]')
        for element in json_ld_elements:
            try:
                json_ld_content = element.get_attribute('innerHTML')
                json_data = json.loads(json_ld_content)
                
                # Check if this JSON-LD contains the product data we're looking for
                if isinstance(json_data, dict) and json_data.get("@type") == "Product":
                    return json_data  # Return the product data JSON-LD if found
            except json.JSONDecodeError as e:
                logging.error(f"Error parsing JSON-LD: {e}")
    except Exception as e:
        logging.error(f"No JSON-LD found: {e}")
    return None

def check_gtin_in_json_ld(driver, expected_upc, expected_alternate_upc):
    """Checks the product page for the correct GTIN by extracting JSON-LD data."""
    try:
        # Extract the JSON-LD from the page
        json_ld = extract_json_ld(driver)
        
        if json_ld:
            # Extract the GTIN (gtin) from the JSON-LD
            actual_gtin = json_ld.get("gtin")
            logging.info(f"Found GTIN in JSON-LD: {actual_gtin}")
            
            if actual_gtin:
                # Clean the GTIN value and compare it with UPC and Alternate UPC
                actual_gtin_cleaned = actual_gtin.lstrip('0').strip()

                # Clean the UPC and Alternate UPC from input
                input_upc_cleaned = expected_upc.lstrip('0').strip()
                input_alternate_upc_cleaned = expected_alternate_upc.lstrip('0').strip()

                # Check if the cleaned GTIN matches either UPC or Alternate UPC
                if actual_gtin_cleaned == input_upc_cleaned:
                    logging.info(f"Matched with UPC: {input_upc_cleaned}")
                    return driver.current_url  # Return the product URL if UPC matches

                elif actual_gtin_cleaned == input_alternate_upc_cleaned:
                    logging.info(f"Matched with Alternate UPC: {input_alternate_upc_cleaned}")
                    return driver.current_url  # Return the product URL if Alternate UPC matches
                else:
                    logging.info(f"GTIN did not match with either UPC or Alternate UPC: {actual_gtin_cleaned} vs {input_upc_cleaned}, {input_alternate_upc_cleaned}")
            else:
                logging.info("No GTIN found in JSON-LD.")
        else:
            logging.info("No valid JSON-LD found on the page.")
    
    except Exception as e:
        logging.error(f"Error checking GTIN in JSON-LD: {e}")

    return None  # Return None if no match is found

def func(search_text: str, expected_upc: str, expected_alternate_upc: str, driver):
    search_url = f"https://www.webstaurantstore.com/search/{search_text}.html"
    logging.info(f"Searching for: {search_text} | UPC: {expected_upc} | Alternate UPC: {expected_alternate_upc} url: {search_url}")

    try:
        driver.get(search_url)
        wait = WebDriverWait(driver, 20)

        # Get all product elements
        product_elements = wait.until(EC.presence_of_all_elements_located(
            (By.CSS_SELECTOR, 'div.product-box-container')
        ))
        logging.info(f"Found {len(product_elements)} products on the search results page.")

        for index in range(len(product_elements)):
            try:
                product_element = product_elements[index]
                logging.info(f"Attempting to click on product {index + 1}.")
                product_element.click()
                time.sleep(3)  # Allow the page to load

                # Now, check the GTIN in the JSON-LD
                product_url = check_gtin_in_json_ld(driver, expected_upc, expected_alternate_upc)

                if product_url:
                    logging.info(f"Product URL found: {product_url}")
                    return product_url

                # If no match was found in JSON-LD, go back and try next product
                driver.back()
                time.sleep(2)

                # Re-fetch the product elements
                product_elements = wait.until(EC.presence_of_all_elements_located(
                    (By.CSS_SELECTOR, 'div.h-full.m-0.relative.border-solid.border-white.border-2.rounded-md')
                ))
                continue  # Try the same product again

            except Exception as product_error:
                logging.error(f"Error processing product {index + 1}: {product_error}", exc_info=True)
                continue

    except Exception as e:
        logging.error(f"An error occurred in fetching products: {e}")

    return None

def main(input_file, output_file):
    last_id = get_identification_value()
    logging.info(f"Last identification value: {last_id}")

    logging.info(f"Reading input file: {input_file}")
    
    with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
        inputs = f.readlines()

    total_products = len(inputs)
    logging.info(f"Total products to process: {total_products}")

    processed_ids = set()
    if os.path.exists(IDENTIFICATION_FILE):
        with open(IDENTIFICATION_FILE, 'r', encoding='utf-8', errors='ignore') as f:
            processed_ids = {line.split('\t')[0].strip() for line in f.readlines()}

    with open(output_file, 'a') as f:
        f.write("ID\tproduct_url\n")  # Write header once

        for index, input_record in enumerate(inputs, start=1):
            input_splits = input_record.strip().split('\t')
            if len(input_splits) < 8:
                logging.warning(f"Skipping invalid record: {input_record.strip()}")
                continue
            
            strike_id = input_splits[0].strip()
            if strike_id in processed_ids:
                continue
            
            brand = input_splits[1].strip()
            mpn = input_splits[2].strip()
            upc = input_splits[3].strip()
            alternate_upc = input_splits[4].strip()  # Alternate UPC is now being used
            title = input_splits[5].strip()
            price = input_splits[6].strip()
            prod_url = input_splits[7].strip()
            search_text = input_splits[8].strip()

            logging.info(f"Processing product {index} of {total_products}: {strike_id} {search_text}")
            product_url = func(search_text, upc, alternate_upc, web_driver)  
            
            if product_url:
                result_line = f"{strike_id}\t{product_url}\n"
                f.write(result_line)  # Write result immediately
                logging.info(f"Product URL found for strike ID: {strike_id} - {product_url}")
            else:
                logging.info(f"Product URL not found for strike ID: {strike_id}")

            update_identification_file(strike_id)
            f.flush()

    logging.info("All results written to output file.")
    print("All results written to output file.")

if __name__ == "__main__":
    last_id = get_identification_value()  
    print(f"Last identification value: {last_id}")
    main('input.txt', 'output.txt')
    web_driver.quit()
